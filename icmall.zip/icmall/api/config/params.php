<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2015/3/31
 * Time: 16:39
 */

return [
//    'serverName' => 'http://test.jz.life',// http://api.jzlifeimg.com/upload/2015/10/30/20151030065324113.jpg
    'serverName' => 'http://img.jzlifeimg.com',
    'goods_currency' => 'USD',
    'usdtocny' => '6.52',
    'cnytousd' => '0.1534',
    'mail_address' => 'services@mallyy.com',
    'style' =>
        array(
            'name' => '家装风格',
            'content' => array(
                0=> '简约风格',
                1=> '现代风格',
                2=> '古典风格',
                3=> '意式风格',
                4=> '德式风格',
                5=> '其他风格',
            )
        ),
    'secretKey' => 'e10adc3949ba59abbe56e057f20f883e',
    'expire_time' => '2592000',//access_token过期时间为30天
    'tax' => '10',
    // 短信接口配置
    'hsms' => array(
        'userid'    => '11320',
        'username'  => '买洋洋',
        'password'  => 'OnrampSMS9460'
    ),

    // 兴趣配置
    'likes' => array(
        '1'=>'进口家具',
        '2'=>'进口家电',
        '3'=>'厨房电器',
        '4'=>'卫浴设备',
        '5'=>'周边产品'
    ),

    // 邮箱配置
    'email' => array(
        'type'      => '1',
        'safe'      => '',
        'address'   => 'services@mallyy.com',
        'smtp'      => 'smtp.mallyy.com',
        'smtp_user' => 'services',
        'smtp_pwd'  => 'Myy!!onramp',
        'smtp_port' => '25',
    ),

    // 发送邮箱配置
    'noticeMail' => array(
        'simple_design_apply'   => array ( 'jackwu@mallyy.com','alisax@polylink.net'),
        // 询价邮件配置
        'site_enquiry_info'     => array ('jackwu@mallyy.com','luvi@jz.life'),
        'ucenter_refund_add'    => array ('jackwu@mallyy.com','luvi@jz.life'),
//        'ucenter_refund_add'    => array ('alisax@polylink.net','luvi@jz.life'),
        'ucenter_withdraw_apply'=> array ('jackwu@mallyy.com', 'luvi@jz.life')
    ),
    'upload' => 'upload',
    'payPath' => '../modules/v1/controllers/',
    //移动端支付宝相关配置
    'partner'=> '2088911952599752',//支付宝合作者身份ID，以2088开头的16位纯数字
    'seller_id' => 'accounting@on-ramp-service.com',//支付宝账号，通常为邮箱地址
    //商户私钥
    'priKey' => "-----BEGIN RSA PRIVATE KEY-----
MIICWwIBAAKBgQDXT5/YIS9hvGyAvzuSWMq/tYbC0vvQoGlrMFNHxTWSkU6WYrJ7
xcSi1HioGFUopjrUolEdIOpqYoItCcZ5PlAONVPmDHkbanYYaE2nTm/2vVg6FNxm
ygYf5vLuM/GCH10kpVlpep9f/0S8B+uXxdknpyxWrUxwHKRdm+J/LPypRwIDAQAB
AoGASbCoxnHlI5A3moDYxKe7DI32R2uqX6bnLZZmimPGiBlPSk0RRSdUu134xZ8+
ViE+dVPwawW+9RYt83grA4f+IZ3j8GtiaUKlEvmVtzeXhFTqcyMdOcGLPcHsiraq
MWMbgIUGzLG3RSrzBM/W3Kf7hDv6XdLd+mPDVidlKdtdGMECQQD1o7/BbfZvhkxk
XlZdIioufXRSjYdeFE55rbeAn01dmTnM/inCCn21cDzZOK/rA4aF3Iesjf2EQm7L
xvsMxTVxAkEA4GRoULfGQr7K6YRAGr+i03wzj080iH1AMN4q0R9NXzZ8+Y3V9ap3
wRjGGEOZAJCZcX6gz4g4XhwEGgzwP9IONwJAUwVDHBcUQWE8lHel7NhNNWVFWVlo
NQ3b8BgceyZcOZQ+CuCkMGbnUdlbV3dnTaDlaHy+hj1/P6JMXCcmVoyYoQJANRSr
dIS0mq9lcq39OBajHuIflEQJSkxOtgCoIkYEWIScNbBur6l+oKgKnEzJUc/i7G0m
/1Da/LAl7D+pSX+YKwJAT/ZTW74FJjFQzv69Wa0SHJopjARF580vRqqfwQoyNq80
wg1AiFMSQDbnYFkrKSubutpxqipmBWqLP/N2FLUhSA==
-----END RSA PRIVATE KEY-----
",
    //支付宝公钥
    'publicKey' => '-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCnxj/9qwVfgoUh/y2W89L6BkRA
FljhNhgPdyPuBV64bfQNN1PjbCzkIM6qRdKBoLPXmKKMiFYnkd6rAoprih3/PrQE
B/VsW8OoM8fxn67UDYuyBTqA23MML9q1+ilIZwBC2AQ2UBVOrFXfFl75p6/B5Ksi
NG9zpgmLCUYuLkxpLQIDAQAB
-----END PUBLIC KEY-----',
    'forex_biz' => 'FP',
    'currency' => 'USD',
    'callback' => 'http://api.jzlifeimg.com',
    //微信登录相关配置
    'Appid' => 'wxd84093bc730e0fb4',
    'secret' => '14c7e0749899d5256f5e9acc2c62611f',
    //消息推送相关配置
    'APPKEY' => 'd2X4C4Y3uo5TNBn5vpaOe8',
    'APPID' => 'MRZKTCAlut5zleWPqSIGIA',
    'MASTERSECRET' => 'I2xk2ZaejJA0d4sZosK3P4',
    'HOST'=> 'http://sdk.open.api.igexin.com/apiex.htm',
    //阿里云oss文件上传
    'oss'=>array(
        'ossServer' => 'http://oss-cn-shenzhen.aliyuncs.com', //服务器外网地址，深圳为 http://oss-cn-shenzhen.aliyuncs.com
        'ossServerInternal' => '//oss-cn-shenzhen-internal.aliyuncs.com', //服务器内网地址，深圳为 http://oss-cn-shenzhen-internal.aliyuncs.com
        'AccessKeyId' => '8MdbDI98opGKzuz7', //阿里云给的AccessKeyId
        'AccessKeySecret' => 's851ha8pp9UHoZ3dlsMGwSV7TDBJ8f', //阿里云给的AccessKeySecret
        'Bucket' => 'jzlife' //创建的空间名
    ),
    'name' => '精致生活',//发件名
    'findPassword' => 'http://www.jz.life/simple/restore_password/hash/',//找回密码链接路径
];