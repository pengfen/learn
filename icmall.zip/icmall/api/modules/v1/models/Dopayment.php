<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/11
 * Time: 14:05
 * @file util.php
 * @brief 公共函数类
 */
namespace api\modules\v1\models;

use Yii;
use yii\rest\ActiveController;
use yii\web\Response;
use yii\filters\auth\HttpBasicAuth;
use yii\helpers\ArrayHelper;
use yii\filters\auth\CompositeAuth;
use yii\filters\auth\HttpBearerAuth;
use yii\filters\auth\QueryParamAuth;
use yii\filters\AccessControl;
use yii\data\ActiveDataProvider;
use yii\filters\ContentNegotiator;
use yii\filters\RateLimiter;
use yii\filters\VerbFilter;
use api\modules\v1\models\Payment;
use api\modules\v1\models\LogOperation;
class Dopayment extends ActiveController{
    /**
     * 移动端支付
     * @brief alsiaxu 2015-12-7
     * @param $order_id 订单ID
     * @param $payment_id 支付方式ID
     * @param $order_no 唯一的订单号
     * @param $total 支付的金额
     */
    public static function getPaymentInfo($order_id,$payment_id,$order_no,$total){
        //生成待签名的字符串
        $orderInfo = self::signStr($order_id,$payment_id,$order_no,$total);
        //签名
        $sign = self::rsaSign($orderInfo);

        //生成订单
        return $orderInfo.'&sign="'.$sign.'"&sign_type="RSA"';
    }
    //生成待签名的字符串
    public static function signStr($order_id,$payment_id,$order_no,$total){
        $partner = yii::$app->params['partner'];//支付宝PartnerID
        // 支付宝账号，通常为邮箱地址
        $seller_id = yii::$app->params['seller_id'];
        // 异步通知地址
        $notify_url = urlencode(yii::$app->params['callback']."/v1/other/callback");
        // 订单标题
        $subject = '精致生活订单';
        $forex_biz = yii::$app->params['forex_biz'];
        $currency = yii::$app->params['currency'];
        // 订单详情
        $body = '精致生活订单';
        // 订单号，示例代码使用时间值作为唯一的订单ID号
        $out_trade_no = $order_no.'_'.date('YmdHis', time());
        $parameter = array(
            'service'        => 'mobile.securitypay.pay',   // 必填，接口名称，固定值
            'partner'        => $partner,                   // 必填，合作商户号
            '_input_charset' => 'UTF-8',                    // 必填，参数编码字符集
            'out_trade_no'   => $out_trade_no,              // 必填，商户网站唯一订单号
            'subject'        => $subject,                   // 必填，商品名称
            'payment_type'   => '1',                        // 必填，支付类型
            'seller_id'      => $seller_id,                 // 必填，卖家支付宝账号
            'rmb_fee'        => $total,
//            'total_fee'      => 0.04,                     // 必填，总金额，取值范围为[0.01,100000000.00]
            'body'           => $body,                      // 必填，商品详情
//            'it_b_pay'       => '1d',                       // 可选，未付款交易的超时时间
            'notify_url'     => $notify_url,                // 可选，服务器异步通知页面路径
//            'show_url'       => $base_path                  // 可选，商品展示网站
            'forex_biz'      => $forex_biz,
            'currency'       => $currency,
        );
        //生成需要签名的订单
        $orderInfo =  self::createLinkstring($parameter);
        return $orderInfo;
    }
    //支付宝回调
    public function callback($callbackData,$paymentId,$money,$message,$order){
        $returnSign = $callbackData['sign'];
        $callbackData['sign']='';
        $callbackData['sign_type']='';
        //除去待签名参数数组中的空值和签名参数
        $para_filter = self::paraFilter($callbackData);

        //对待签名参数数组排序
        $para_sort = self::argSort($para_filter);

        //生成待签名字符串
        $prestr = self::buildMysign($para_sort);
        $prestr = preg_replace('/\"/','',$prestr);

        $OrderExtendInfo = Order_extend::findOne(['order_no' => $order]);
        $order_id = $OrderExtendInfo['order_id'];
        if($callbackData['currency'] == yii::$app->params['currency']){
            $OrderExtendInfo = Order_extend::findOne(['order_no' => $order]);
            $total_price = Util::exchange($callbackData['total_fee']);
            if($total_price == $OrderExtendInfo['amount']) {
                $logData = ['author' => '支付宝','action' => '订单'.$order.'金额验证','content' => '订单'.$order.'美元支付，订单金额与回调金额一致','datetime' => date("y-m-d h:i:s")];
                LogOperation::insertData($logData);
            }else{
                $logData = ['author' => '支付宝','action' => '订单'.$order.'金额验证','content' => '订单'.$order.'美元支付，订单金额与回调金额不一致','datetime' => date("y-m-d h:i:s")];
                LogOperation::insertData($logData);
            }
        }
        $pub_key = yii::$app->params['publicKey'];

        $re = self::rsaVerify($prestr,$pub_key,$returnSign);
        if($re){
            return true;
        }else{
            return false;
        }
    }
    /**
     * RSA验签
     * @param $data 待签名数据
     * @param $ali_public_key_path 支付宝的公钥文件路径
     * @param $sign 要校对的的签名结果
     * return 验证结果
     */
    public static function rsaVerify($data, $pub_key, $sign)  {
        $res = openssl_get_publickey($pub_key);
        $result = (bool)openssl_verify($data, base64_decode($sign), $res);
        openssl_free_key($res);
        return $result;
    }
    /**
     * 除去数组中的空值和签名参数
     * @param $para 签名参数组
     * return 去掉空值与签名参数后的新签名参数组
     */
    public static function paraFilter($para)
    {
        $para_filter = array();
        foreach($para as $key => $val)
        {
            if($key == "sign" || $key == "sign_type" || $val == "")
            {
                continue;
            }
            else
            {
                $para_filter[$key] = $para[$key];
            }
        }
        return $para_filter;
    }
    /**
     * 对数组排序
     * @param $para 排序前的数组
     * return 排序后的数组
     */
    public static function argSort($para)
    {
        ksort($para);
        reset($para);
        return $para;
    }
    /**
     * 生成签名结果
     * @param $sort_para 要签名的数组
     * @param $key 支付宝交易安全校验码
     * @param $sign_type 签名类型 默认值：MD5
     * return 签名结果字符串
     */
    public static function buildMysign($sort_para,$sign_type = "RSA")
    {
        //把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
        $prestr = self::createLinkstring($sort_para);

        return $prestr;
    }
    // 对签名字符串转义
    public static function createLinkstring($para) {
        $arg  = "";
        while (list ($key, $val) = each ($para)) {
            $arg.=$key.'="'.$val.'"&';
        }
        //去掉最后一个&字符
        $arg = substr($arg,0,count($arg)-2);
        //如果存在转义字符，那么去掉转义
        if(get_magic_quotes_gpc()){$arg = stripslashes($arg);}
        return $arg;
    }
    // 签名生成订单信息
    public static function rsaSign($data) {
        //私钥文件 pkcs8转换前的私钥
        $priKey = yii::$app->params['priKey'];
        //获取openssl密钥，必须是没有经过pkcs8转换的私钥
        $res = openssl_pkey_get_private($priKey);
        //调用openssl内置签名方法，生成签名$sign
        openssl_sign($data, $sign, $res);
        //释放资源
        openssl_free_key($res);
        //base64编码
        $sign = base64_encode($sign);
        $sign = urlencode($sign);
        return $sign;
    }
    /**
     * @brief 根据支付方式配置编号  获取该插件的配置信息
     * @param $payment_id int    支付方式ID
     * @param $key        string 字段
     * @return 返回支付插件类对象
     */
    public static function getConfigParam($payment_id,$key = '')
    {
        $payConfig = self::getPaymentById($payment_id,'config_param');
        if($payConfig)
        {
            $payConfig = json_decode($payConfig);
            return isset($payConfig->$key) ? $payConfig->$key : '';
        }
        return '';
    }
    /**
     * @brief 根据支付方式配置编号  获取该插件的详细配置信息
     * @param $payment_id int    支付方式ID
     * @param $key        string 字段
     * @return 返回支付插件类对象
     */
    public static function getPaymentById($payment_id,$key = '')
    {
        $paymentRow = Payment::findOne(['id' => $payment_id]);

        if($key)
        {
            return isset($paymentRow[$key]) ? $paymentRow[$key] : '';
        }
        return $paymentRow;
    }
    /**
     * @brief alisaxu  notifyStop()
     */
    public function notifyStop()
    {
        echo "success";
    }
}