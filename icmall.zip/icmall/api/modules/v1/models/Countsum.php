<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/17
 * Time: 16:46
 * @file Mess.php
 * @brief 站内消息的管理
 */
namespace api\modules\v1\models;

use Yii;
use yii\rest\ActiveController;
use yii\web\Response;
use yii\filters\auth\HttpBasicAuth;
use yii\helpers\ArrayHelper;
use yii\filters\auth\CompositeAuth;
use yii\filters\auth\HttpBearerAuth;
use yii\filters\auth\QueryParamAuth;
use yii\filters\AccessControl;
use yii\data\ActiveDataProvider;
use yii\filters\ContentNegotiator;
use yii\filters\RateLimiter;
use yii\filters\VerbFilter;
use api\modules\v1\models\Goods_car;
use api\modules\v1\models\Goods;
use api\modules\v1\models\Brand;
use api\modules\v1\models\Products;
use yii\db\Query;
/**
 * @brief alisaxu 计算购物车中的价格操作类
 */
class Countsum extends ActiveController{
    //购物车计算
    public static function Cart_count($goodIds="",$productIds="",$flag = false,$data = array(),$user_id)
    {
        //获取购物车中的商品和货品信息
        $myCartInfo = Cart::Getbalance($productIds,$goodIds,$data);

        if ($flag == true) {
            $data =  Countsum::goodsCount($myCartInfo,$user_id); // 生成订单相关数据
            return $data;
        }
    }
    /**
     * @brief alisaxu 2015-11-23 拆单（根据价格判断是否生成多单）
     * @param Array $buyInfo,购物车格式
     * @param $user_id 用户ID
     * @return array or bool
    */
    public static function goodsCount($buyInfo,$user_id)
    {
        $sum = 0;  //原始总额
        $old_custom_price = 0; //原始清关价
        $custom = 0;       // 清关总价
        $goodsList = array();  //商品列表
        $delivery_type = 1;
        $goods = array();  //订单中数据
        $num = 0; //总订单数
        $remain = 0;
        $remainkey = array();
        $remainInfo = array();

        //获取商品或货品数据
        if (isset($buyInfo['goods']['id']) && !empty($buyInfo['goods']['id']) || isset($buyInfo['product']['id']) && !empty($buyInfo['product']['id'])) {
            $goodsCheckId = (isset($buyInfo['goods']['id']) && !empty($buyInfo['goods']['id'])) ? 1:0;
            $productCheckId = (isset($buyInfo['product']['id']) && !empty($buyInfo['product']['id'])) ? 1:0;
            $goodsCheck = (isset($buyInfo['goods']['data']) && !empty($buyInfo['goods']['data'])) ? 1:0;
            $productCheck = (isset($buyInfo['product']['data']) && !empty($buyInfo['product']['data'])) ? 1:0;
            //购物车中同时具有商品和货品
            if ($goodsCheckId == 1 && $productCheckId == 1 && $goodsCheck == 1 && $productCheck == 1) {
                $goodsList = $buyInfo['goods']['data'] + $buyInfo['product']['data'];
            }
            //购物车中有商品没有货品
            if (($goodsCheckId == 1 && $goodsCheckId == 0 && $goodsCheck == 1) || ($goodsCheckId == 1 && $goodsCheckId == 1 && $goodsCheck == 1 && $productCheck == 0)) {
                $goodsList = $buyInfo['goods']['data'];
            }
            //购物车中有货品没有商品
            if (($goodsCheckId == 0 && $productCheckId == 1 && $productCheck == 1) || ($goodsCheckId == 1 && $goodsCheckId == 1 && $goodsCheck == 0 && $productCheck == 1)) {
                $goodsList = $buyInfo['product']['data'];
            }
            //根据清关价对需要结算的数组进行降序排序
            $custompriceArray = array();
            foreach($goodsList as $k=>$v){
                $custompriceArray[] = $v['custom_price'];
            }
            $custompriceArray = array_unique($custompriceArray);
            arsort($custompriceArray);
            $goodsInfo = array();
            foreach($custompriceArray as $custon=>$price){
                foreach($goodsList as $ke => $va){
                    if($va['custom_price'] == $price){
                        $goodsInfo[$ke] = $va;
                    }
                }
            }
            $goodsList = $goodsInfo;
            //提交的购物车信息中商品种类
            $kind = $kindNew =  count($goodsList);
            $j = 0;
            foreach ($goodsList as $key => $val) {
                $kind -= 1;
                //检查库存
                if ($val['store_nums'] <= 0 || $val['count'] > $val['store_nums']) {
                    $result = ['is_Error' => true, 'message' => "商品：" . $val['name'] . "购买数量超出库存，请重新调整购买数量"];
                }
                $goodsList[$key]['count'] = $val['count'];
                $custom_price = $goodsList[$key]['custom_price'];
                $custom_price = $old_custom_price = ($custom_price > 0) ? Util::exchange($custom_price) : Util::exchange($goodsList[$key]['cost_price'] * 0.7);
                //判断上一件商品是否没有生产订单
                if($remainkey){
                    $k = 0;
                    foreach($remainkey as $k=>$v){
                        $k += 1;
                        if($k == count($remainInfo)) {
                            $custom_price += $remainInfo[$v]['custom_price'];//加上滞留数组中最后一维数组中的清关价
                        }
                    }
                }

                $buy_num = 1;
                $curcount = $count = $goodsList[$key]['count'];
                for ($i = 1; $i <= $count; $i++) {
                    $curcount -= 1;
                    //一个商品买多件多件清关价大于1000
                    if ($custom_price > 1000 ) {
                        $j = $i;
                        //当购买数量不为1且清关价大于1000，则把前一件商品生成一个订单
                        if($buy_num != 1) {
                            $i -= 1;
                            $buy_num -= 1;
                        }
                        //滞留数组为空
                        if(empty($remainkey) && $kindNew>= 1) {
                            $goods[$num][$key] = $val;
                            $goods[$num][$key]['count'] = $buy_num;
                        }
                        //滞留数组不为空
                        else{
                            //如果滞留数组不为空时，则把滞留数组生产订单
                            foreach($remainkey as $k=>$v){
                                $goods[$num][$v] = $goodsList[$v];
                                $goods[$num][$v]['count'] = $remainInfo[$v]['count'];
                            }
                            if($old_custom_price > 1000) {
                                $num += 1;
                                $buy_num = 1;
                            }
                            //不是该商品的第一件则在同一订单中生成
                            if($j != 1){
                                $goods[$num][$key] = $val;
                                $goods[$num][$key]['count'] = $buy_num;
                            }
                            //是该商品的第一件
                            else{
                                $i -= 1;
                            }
                        }
                        //清空滞留数组
                        $remainkey = array();
                        $remainInfo = array();

                        $num += 1;
                        $buy_num = 1;
                        $custom_price = $old_custom_price;
                    }
                    //一个商品买多件清关价小于1000
                    else {
                        //是否是商品的最后一件
                        if ($curcount <= 0) {
                            //是购物车的最后一件商品（生产订单）
                            if($kind <= 0) {
                                if(!empty($remainInfo)) {
                                    foreach ($remainkey as $k => $v) {
                                        $goods[$num][$v] = $goodsList[$v];
                                        $goods[$num][$v]['count'] = $remainInfo[$v]['count'];
                                    }
                                }
                                $goods[$num][$key] = $val;
                                $goods[$num][$key]['count'] = $buy_num;
                            }
                            //不是最后一件则放在滞留数组
                            $remainkey[] = $key;
                            $remainInfo[$key] = ['custom_price'=>$custom_price,'count'=>$buy_num];//添进去的清关价为累加的
                        }
                        $custom_price += $old_custom_price;
                        $buy_num += 1;
                    }
                }
            }
        }
        $result = ['is_Error' => false, 'data' => $goods];
        return $result;
    }
    /**
     * 获取商品的税金
     * @param $goodsSum float 商品总价格
     * @return $goodsTaxPrice float 商品的税金
     */
    public static function getGoodsTax($goodsSum)
    {
        $goodsTaxPrice = 0;
        $tax_per       = isset(yii::$app->params['tax']) ? yii::$app->params['tax'] : 0;
        $goodsTaxPrice = $goodsSum * ($tax_per * 0.01);
        return $goodsTaxPrice;
    }
    //取得多单一件商品中多收的运费
    public static function getPreferentialFreightExtend($goodsList,$weight,$count){
        //运费
        $price = (15 + ceil(intval($weight) / 1000) * 30);
        //实收
        $sum =0;
        $delivery_type = 1;
        $type=0;
        $delivery_type = $goodsList["delivery_type"];
        $sum = $sum + (15 + ceil(intval($goodsList["weight"]) / 1000) * 30) * $count;
        $type=$goodsList['type'];
        //空运多收的运费
        if($delivery_type==1) {
            if($type==0)
                return $sum - $price;
            else
                return 0;
        }
    }
    /**
     * 计算购物车中的商品价格、运费、税金以
     * @brief alisaxu 2015-11-26
     * @param $orderInfo 所有的订单信息
    */
    public static function goodsCountExchange($cartInfo){
        $orderInfo = array();
        $all_sum = 0;
        $all_freightPrice = 0;
        $all_freight = 0;
        $all_taxPrice = 0;
        //实付款 商品总额-运费立减+税金
        $all_real_payment = 0;
        foreach($cartInfo as $key=>$value){
            //商品总额
            $sum = $lowest_price = 0;
            //多收的运费总额
            $freightPrice = 0;
            //税金总额
            $taxPrice = 0;
            $freight = 0;
            $real_payment = 0;
            $alow_key = 0;
            foreach($value as $k=>$v) {
                $orderInfo['order'][$key]['goodsInfo'][$alow_key] = $v;
                //判断是否是大件
                $type = Goods::findOne(['id' => $v['goods_id']])['type'];
                $orderInfo['order'][$key]['goodsInfo'][$alow_key]['sell_price'] = Util::priceRound(Util::exchange($v['sell_price']));
                $orderInfo['order'][$key]['goodsInfo'][$alow_key]['cost_price'] = Util::exchange($v['cost_price']);
                $orderInfo['order'][$key]['goodsInfo'][$alow_key]['lowest_price'] = Util::exchange($v['lowest_price']);
                $orderInfo['order'][$key]['goodsInfo'][$alow_key]['sum'] = $v['count'] * $orderInfo['order'][$key]['goodsInfo'][$alow_key]['sell_price'];
                //获取商品所属品牌
                $orderInfo['order'][$key]['goodsInfo'][$alow_key]['brandName'] = Brand::findOne(['id' => $v['brand_id']])['name'];
                //获取国内专柜价或者参考价
                if($v['if_price'] > 0){
                    $orderInfo['order'][$key]['goodsInfo'][$alow_key]['if_price'] = '参考价';
                }else{
                    $orderInfo['order'][$key]['goodsInfo'][$alow_key]['if_price'] = '国内专柜价';
                }
                if($v['real_market_price'] > $v['sell_price']){
                    $orderInfo['order'][$key]['goodsInfo'][$alow_key]['reference_price'] = Util::exchange($v['real_market_price']);
                }
                //商品是大件时
                if ($type == 1) {
                    $orderInfo['order'][$key]['goodsInfo'][$alow_key]['freightPrice'] = 0;
                    $orderInfo['order'][$key]['goodsInfo'][$alow_key]['freight'] = 0;
                    $orderInfo['order'][$key]['goodsInfo'][$alow_key]['taxPrice'] = 0;
                } //商品是小件时计算运费以及税金
                else {
                    $orderInfo['order'][$key]['goodsInfo'][$alow_key]['taxPrice'] = Countsum::getGoodsTax($orderInfo['order'][$key]['goodsInfo'][$alow_key]['sum']);
                    //多收的运费
                    $freight = (15 + ceil(intval($v['weight']) / 1000) * 30);
                    $orderInfo['order'][$key]['goodsInfo'][$alow_key]['freight'] = $freight;//实收运费
                    $orderInfo['order'][$key]['goodsInfo'][$alow_key]['freight'];
                    $orderInfo['order'][$key]['goodsInfo'][$alow_key]['freightPrice'] = Countsum::getPreferentialFreightExtend($v, $v['weight'],$v['count']);//多收运费
                }
                $sum += $orderInfo['order'][$key]['goodsInfo'][$alow_key]['sum'];
                $lowest_price += $orderInfo['order'][$key]['goodsInfo'][$alow_key]['lowest_price'];
                $freightPrice += $orderInfo['order'][$key]['goodsInfo'][$alow_key]['freightPrice'];
                $freight += $orderInfo['order'][$key]['goodsInfo'][$alow_key]['freight'];
                $taxPrice += $orderInfo['order'][$key]['goodsInfo'][$alow_key]['taxPrice'];

                $alow_key += 1;
            }
            //单个订单所有商品的总额、多收的运费以及税金
            $orderInfo['order'][$key]['one_price']['sum'] = Util::priceRound($sum);
            $orderInfo['order'][$key]['one_price']['lowest_price'] = $lowest_price;
            $orderInfo['order'][$key]['one_price']['freightPrice'] = $freightPrice;
            $orderInfo['order'][$key]['one_price']['freight'] = $freight;
            $orderInfo['order'][$key]['one_price']['taxPrice'] = $taxPrice;
            //实付款 商品总额-运费立减+税金
            $orderInfo['order'][$key]['one_price']['real_payment'] = Util::priceRound($sum - $freightPrice + $taxPrice);
            //所有订单所有商品的总额、多收的运费以及税金
            $all_sum += $orderInfo['order'][$key]['one_price']['sum'];
            $all_freightPrice += $orderInfo['order'][$key]['one_price']['freightPrice'];
            $all_freight += $orderInfo['order'][$key]['one_price']['freight'];
            $all_taxPrice += $orderInfo['order'][$key]['one_price']['taxPrice'];
            $all_real_payment += $orderInfo['order'][$key]['one_price']['real_payment'];

        }
        $orderInfo['total_price']['sum'] = Util::priceRound($all_sum);
        $orderInfo['total_price']['freightPrice'] = $all_freightPrice;
        $orderInfo['total_price']['freight'] = $all_freight;
        $orderInfo['total_price']['taxPrice'] = $all_taxPrice;
        //实付款 商品总额-运费立减+税金
        $orderInfo['total_price']['real_payment'] = Util::priceRound($all_real_payment);

        return $orderInfo;
    }
}