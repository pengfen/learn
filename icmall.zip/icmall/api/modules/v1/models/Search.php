<?php
namespace api\modules\v1\models;

use yii\web\Link;
use yii\web\Linkable;
use yii\helpers\Url;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;

/**
 * Country Model
 *
 * @author Budi Irawan <deerawan@gmail.com>
 */
class Search extends ActiveRecord //\common\models\Ad_manage
{
    private static $users = [
        '100' => [
            'id' => '100',
            'username' => 'admin',
            'password' => 'admin',
            'authKey' => 'test100key',
            'accessToken' => '100-token',
        ],
        '101' => [
            'id' => '101',
            'username' => 'demo',
            'password' => 'demo',
            'authKey' => 'test101key',
            'accessToken' => '101-token',
        ],
    ];
    public static function findIdentityByAccessTokenByArray($token, $type = null)
    {
        foreach (self::$users as $user) {
            if ($user['accessToken'] === $token) {
                return new static($user);
            }
        }

        return null;
    }
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%onramp_search}}';
    }
    /**
     * ����SQL����ȡ��������
     * @return null|static
     */
    public static function selectOne($sql='')
    {
        $db = \Yii::$app->db;
        if (empty($sql)) return false;
        $result = $db->createCommand($sql)->queryAll();
        return !empty($result) && is_array($result) ? $result[0] : array();
    }
    /**
     * ����SQL����ȡ��������
     * @return null|static
     */
    public static function selectAll($sql='')
    {
        $db = \Yii::$app->db;
        if (empty($sql)) return false;
        $result = $db->createCommand($sql)->queryAll();
        return $result;
    }
    /**
     * @brief ��������
     * @param bool $data        ��������
     */
    public static function insertData(array $data=array())
    {
        $db = \Yii::$app->db;
        if(!is_array($data) || empty($data)) return false;
        $result = $db->createCommand()->insert(self::tableName(), $data)->execute();
        if($result) {
            return  $db->getLastInsertID();
        }
        return false;
    }

    /**
     * @brief ��������
     * @param bool $data        ��������
     * @param string $where     ��������
     */
    public static function updateData(array $data=array(), $where='')
    {
        $db = \Yii::$app->db;
        if(!is_array($data) || empty($data)) return false;
        if(empty($where) || $where == '') return false;

        $result = $db->createCommand()->update(self::tableName(), $data, $where)->execute();
        return $result;
    }
}
