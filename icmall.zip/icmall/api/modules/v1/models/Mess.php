<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/17
 * Time: 16:46
 * @file Mess.php
 * @brief 站内消息的管理
 */
namespace api\modules\v1\models;

use Yii;
use yii\rest\ActiveController;
use yii\web\Response;
use yii\filters\auth\HttpBasicAuth;
use yii\helpers\ArrayHelper;
use yii\filters\auth\CompositeAuth;
use yii\filters\auth\HttpBearerAuth;
use yii\filters\auth\QueryParamAuth;
use yii\filters\AccessControl;
use yii\data\ActiveDataProvider;
use yii\filters\ContentNegotiator;
use yii\filters\RateLimiter;
use yii\filters\VerbFilter;
use api\modules\v1\models\Message;
use api\modules\v1\models\Member;
use api\modules\v1\models\User;
use api\modules\v1\models\PushMessage;
class Mess extends ActiveController{
    /**
     * 直接发站内信到用户
     * @param $userIds string 用户Id的串
     * @param $content 信件内容 array('title' => '标题','content' => '内容')
     */
    public static function sendToUser($userIds,$content)
    {
        set_time_limit(0);

        //插入$content
        $msgDB = new Message;
        $msgDB->type = $content['type'];
        $msgDB->title = $content['title'];
        $msgDB->content = $content['content'];
        $msgDB->time = date('Y-m-d H:i:s');
        $res = $msgDB->save();
        $id = $msgDB->attributes['id'];


        if(!$res)
        {
            return false;
        }
        else
        {
            $memberTB = new Member();
            if($userIds)
            {
                $model = Member::findOne($userIds);
                $model->message_ids = $model['message_ids'].$id.',';
                $res = $model->update();
                return true;
            }
        }
    }
    /**
     * @brief 获得member表中的messageid,去掉 '-' 且没有最后的 ',' 的message的id
     * @return $message array 返回站内所有消息id的数组
     */
    public static function getAllMsgIds($str)
    {
        return Util::explode(str_replace('-','',trim($str,',')));
    }
    /**
     * @brief 判断messageid是否已经读过
     * @param $mess_id int message的id
     * @return $is_blog boolean 返回true为已读，false为未读
     */
    public static function is_read($messageId,$messageIds)
    {
        if(strpos(','.trim($messageIds,',').',',',-'.$messageId.',') === false)
        {
            return false;
        }
        return true;
    }
    //根据用户ID发送个推消息
    /**
     * $param $osname ios则使用透传模板，否则使用通知透传模板
     */
    public static function pushMessge($user_id,$message="精致生活，高档的生活节奏",$osname){
        $info = "";
        if($user_id) {
            $cid = User::findOne(['id' => $user_id]);
            Yii::$app->cache->set("findOne".$cid['clientId'],$user_id);
            if(isset($cid['clientId']) &&!empty($cid['clientId'])) {
                $clientId = $cid['clientId'];
                $res = new PushMessage();
                $info = $res->pushMessageToSingle($clientId,$message,$osname);
            }
        }
        return $info;
    }
    /**
     * @brief 将messageid写入member表中
     * @param $message_id int 消息的id
     * @param $read int 0:未读(追加到用户id串后面)，1:已读(把用户id串增加‘-’负号)
     * @return int or boolean
     */
    public static function writeMessage($message_id,$messageIds,$read = 0)
    {
        if($read == 1)
        {
            $tempIds = ','.trim($messageIds,',').',';
            if(strpos($tempIds,','.$message_id.',') === false)
            {
                return false;
            }
            $tempIds = str_replace(','.$message_id.',',',-'.$message_id.',',$tempIds);
            $messageIds = trim($tempIds,',').',';
        }
        else
        {
            $messageIds .= $message_id.',';
        }

        return $messageIds;
    }
}