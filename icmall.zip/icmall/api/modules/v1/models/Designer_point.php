<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/12/12
 * Time: 16:39
 */
namespace api\modules\v1\models;

use yii\web\Link;
use yii\web\Linkable;
use yii\helpers\Url;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;

/**
 * Country Model
 *
 * @author Budi Irawan <deerawan@gmail.com>
 */
class Designer_point extends ActiveRecord implements IdentityInterface //\common\models\User
{
    use \damirka\JWT\UserTrait;
    const STATUS_DELETED = -1;
    const STATUS_INACTIVE = 0;
    const STATUS_ACTIVE = 1;
    private static $users = [];

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%onramp_designer_point}}';
    }

    /**
     * @inheritdoc
     */
    public static function findIdentity($id)
    {
        return static::findOne(['id' => $id, 'status' => self::STATUS_ACTIVE]);
    }

    /**
     * Finds user by username
     *
     * @param string $username
     * @return static|null
     */
    public static function findByUsername($username)
    {
        return static::findOne(['username' => $username, 'status' => self::STATUS_ACTIVE]);
    }

    /**
     * Finds an identity by the given token.
     * @param mixed $token the token to be looked for
     * @param mixed $type the type of the token. The value of this parameter depends on the implementation.
     * For example, [[\yii\filters\auth\HttpBearerAuth]] will set this parameter to be `yii\filters\auth\HttpBearerAuth`.
     * @return IdentityInterface the identity object that matches the given token.
     * Null should be returned if such an identity cannot be found
     * or the identity is not in an active state (disabled, deleted, etc.)
     */
    public static function findIdentityByAccessToken($token, $type = null)
    {
        // TODO: Implement findIdentityByAccessToken() method.
    }

    /**
     * Returns an ID that can uniquely identify a user identity.
     * @return string|integer an ID that uniquely identifies a user identity.
     */
    public function getId()
    {
        // TODO: Implement getId() method.
    }

    /**
     * Returns a key that can be used to check the validity of a given identity ID.
     *
     * The key should be unique for each individual user, and should be persistent
     * so that it can be used to check the validity of the user identity.
     *
     * The space of such keys should be big enough to defeat potential identity attacks.
     *
     * This is required if [[User::enableAutoLogin]] is enabled.
     * @return string a key that is used to check the validity of a given identity ID.
     * @see validateAuthKey()
     */
    public function getAuthKey()
    {
        // TODO: Implement getAuthKey() method.
    }

    /**
     * Validates the given auth key.
     *
     * This is required if [[User::enableAutoLogin]] is enabled.
     * @param string $authKey the given auth key
     * @return boolean whether the given auth key is valid.
     * @see getAuthKey()
     */
    public function validateAuthKey($authKey)
    {
        // TODO: Implement validateAuthKey() method.
    }

    /**
     * Getter for secret key that's used for generation of JWT
     * @return string secret key used to generate JWT
     */
    protected function getSecretKey()
    {
        // TODO: Implement getSecretKey() method.
    }

    /**
     * Getter for "header" array that's used for generation of JWT
     * @return array JWT Header Token param, see http://jwt.io/ for details
     */
    protected function getHeaderToken()
    {
        // TODO: Implement getHeaderToken() method.
    }

    /**
     * ����SQL����ȡ��������
     * @return null|static
     */
    public static function selectOne($sql='')
    {
        $db = \Yii::$app->db;
        if (empty($sql)) return false;
        $result = $db->createCommand($sql)->queryAll();
        return !empty($result) && is_array($result) ? $result[0] : array();
    }


    /**
     * ����SQL����ȡ��������
     * @return null|static
     */
    public static function selectAll($sql='')
    {
        $db = \Yii::$app->db;
        if (empty($sql)) return false;
        $result = $db->createCommand($sql)->queryAll();
        return $result;
    }

    /**
     * @brief ��������
     * @param bool $data ��������
     */
    public static function insertData(array $data = array())
    {
        $db = \Yii::$app->db;
        if (!is_array($data) || empty($data)) return false;
        $result = $db->createCommand()->insert(self::tableName(), $data)->execute();
        if ($result) {
            return $db->getLastInsertID();
        }
        return false;
    }


    /**
     * @brief ��������
     * @param bool $data ��������
     * @param string $where ��������
     */
    public static function updateData(array $data = array(), $where = '')
    {
        $db = \Yii::$app->db;
        if (!is_array($data) || empty($data)) return false;
        if (empty($where) || $where == '') return false;

        $result = $db->createCommand()->update(self::tableName(), $data, $where)->execute();
        return $result;
    }


    /**
     * @brief ɾ������
     * @param $where string     ɾ������
     */
    public static function deleteData($where = '')
    {
        $db = \Yii::$app->db;
        if (empty($where) || $where == '') return false;

        $result = $db->createCommand()->delete(self::tableName(), $where)->execute();
        return $result;

    }
}
