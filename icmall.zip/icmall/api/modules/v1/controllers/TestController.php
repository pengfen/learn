<?php
namespace api\modules\v1\controllers;

use Yii;
use yii\rest\ActiveController;
use yii\web\Response;

class TestController extends ActiveController
{
    public $modelClass = 'api\modules\v1\models\Goods';
    public $serializer = [
        'class' => 'yii\rest\Serializer',
        'collectionEnvelope' => 'items',
    ];

    public function behaviors()
    {
        $behaviors = parent::behaviors();
        $behaviors['contentNegotiator']['formats']['text/html'] = Response::FORMAT_HTML;
        return $behaviors;
    }

    public function serializeData($data)
    {
        return Yii::createObject($this->serializer)->serialize($data);
    }
//    public function afterAction($action, $result)
//    {
//        $result = parent::afterAction($action, $result);
//        return $this->serializeData($result);
//    }

    public function actions()
    {
        $actions = parent::actions();

        // disable the "delete" and "create" actions
        unset($actions['delete'], $actions['view'],$actions['index']);

        // customize the data provider preparation with the "prepareDataProvider()" method
//        $actions['index']['prepareDataProvider'] = [$this, 'prepareDataProvider'];

        return $actions;
    }

    public function actionIndex(){
        return '调用成功';
    }

}
