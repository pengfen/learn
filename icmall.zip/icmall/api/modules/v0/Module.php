<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2015/3/31
 * Time: 16:38
 */
namespace api\modules\v0;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'api\modules\v0\controllers';

    public function init()
    {
        parent::init();
        \Yii::$app->user->enableSession = false;
    }

    public function behaviors()
    {
        $behaviors = parent::behaviors();
        return $behaviors;
    }
}