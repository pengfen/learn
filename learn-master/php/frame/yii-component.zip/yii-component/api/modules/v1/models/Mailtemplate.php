<?php
namespace api\modules\v1\models;
/**
 * @copyright (c) 2014 mallyy.com
 * @file sendmail.php
 * @brief 邮件数据模板
 * @author chendeshan
 * @date 2014/11/28 23:20:51
 * @version 2.9
 */
use Yii;
use yii\rest\ActiveController;
use api\modules\v1\models\Order_goods;
use api\modules\v1\models\Goods;
use yii\db\Query;
class Mailtemplate
{
    /**
     * @brief 找回密码模板
     * @param array $param 模版参数
     * @return string
     */
    public static function findPassword($param)
    {
        $templateString = "您好，您在".yii::$app->params['name']."申请找回密码的操作，点击下面这个链接进行密码重置：{url}。如果不能点击，请您把它复制到地址栏中打开。";
        return strtr($templateString,$param);
    }
    /**
     * @brief 验证邮件模板
     * @param array $param 模版参数
     * @param
     * @return string
     */
    public static function sendMail($param, $username, $id, $order_no, $seller, $message)
    {
        $templateString = "亲爱的{$seller}您好，有一笔{$message}！

		订单号：{$order_no}
		订单详情： ";
        $goodsList = Order_goods::findAll(['order_id'=> $id]);
        foreach($goodsList as $key=>$val){
            $goods = json_decode($val['goods_array']);
            // 获取品牌名
            $goods_id = $val['goods_id'];
            $goodsTb = Goods::tableName();
            $brandTb = Brand::tableName();
            $query = new Query;
            $query->select(['b.name'])
                ->from($brandTb . 'AS b')
                ->leftJoin($goodsTb . 'AS g', 'b.id = g.brand_id')
                ->where('g.id = ' . $goods_id)
                ->orderBy('g.id asc');
            $brand = $query->one();
            if (isset($brand['name'])) {
                $templateString .= "品牌【{$brand['name']}】";
            }
            $spec = '';
            if (!empty($goods->value)) {
                $spec = "参数规格 【 ";
                if (is_array($goods->value)) {
                    foreach($goods->value as $k=>$v) {
                        if ($v->type != 2) {
                            $spec .= $v->name.':'.$v->value;
                        } elseif (!empty($goods->param)) {
                            $spec .= $goods->param;
                        }
                    }
                } else {
                    $spec .= $goods->value;
                }
                $spec .= '】';
            }
            $templateString .= " 名称【".$goods->name."】 数量【{$val['goods_nums']}】".$spec;
        }

        $templateString .= "
下单用户： {$username}";

        return strtr($templateString,$param);
    }
}
