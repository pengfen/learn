<?php
namespace api\modules\v1\models;

/**
 * SearchEngine Model
 *
 * @author kimi.gu <kimi.gu@jz.life>
 */
class Se_goods extends \hightman\xunsearch\ActiveRecord
{

}
