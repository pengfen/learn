<?php
namespace api\modules\v1\models;

use yii\web\Link;
use yii\web\Linkable;
use yii\helpers\Url;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;

/**
 * Country Model
 *
 * @author Budi Irawan <deerawan@gmail.com>
 */
class Fav extends ActiveRecord implements IdentityInterface //\common\models\Ad_manage
{
    const STATUS_DELETED = -1;
    const STATUS_INACTIVE = 0;
    const STATUS_ACTIVE = 1;

    private static $users = [
        '100' => [
            'id' => '100',
            'username' => 'admin',
            'password' => 'admin',
            'authKey' => 'test100key',
            'accessToken' => '100-token',
        ],
        '101' => [
            'id' => '101',
            'username' => 'demo',
            'password' => 'demo',
            'authKey' => 'test101key',
            'accessToken' => '101-token',
        ],
    ];
    public static function findIdentityByAccessTokenByArray($token, $type = null)
    {
        foreach (self::$users as $user) {
            if ($user['accessToken'] === $token) {
                return new static($user);
            }
        }

        return null;
    }
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%onramp_fav}}';
    }

    public static function findIdentityByAccessToken($token, $type = null)
    {
        return static::findOne(['access_token' => $token]);
    }

    /**
     * @inheritdoc
     */
    public static function findIdentity($id)
    {
        return static::findOne(['id' => $id]);
    }

    /**
     * @inheritdoc
     */
    public function getId()
    {
        return $this->getPrimaryKey();
    }

    /**
     * @inheritdoc
     */
    public function getAuthKey()
    {
        return $this->auth_key;
    }

    /**
     * @inheritdoc
     */
    public function validateAuthKey($authKey)
    {
        return $this->getAuthKey() === $authKey;
    }
    /**
     * @brief 删除数据
     * @param $where string     删除条件
     */
    public static function deleteData($where = '')
    {
        $db = \Yii::$app->db;
        if (empty($where) || $where == '') return false;

        $result = $db->createCommand()->delete(self::tableName(), $where)->execute();
        return $result;
    }
    /**
     * @brief 插入数据
     * @param bool $data 插入数据
     */
    public static function insertData(array $data = array())
    {
        $db = \Yii::$app->db;
        if (!is_array($data) || empty($data)) return false;
        $result = $db->createCommand()->insert(self::tableName(), $data)->execute();
        if ($result) {
            return $db->getLastInsertID();
        }
        return false;
    }


    /**
     * @brief 更新数据
     * @param bool $data 更新数据
     * @param string $where 更新条件
     */
    public static function updateData(array $data = array(), $where = '')
    {
        $db = \Yii::$app->db;
        if (!is_array($data) || empty($data)) return false;
        if (empty($where) || $where == '') return false;

        $result = $db->createCommand()->update(self::tableName(), $data, $where)->execute();
        return $result;
    }
}
