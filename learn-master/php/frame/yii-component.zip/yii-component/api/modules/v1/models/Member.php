<?php
namespace api\modules\v1\models;

use yii\web\Link;
use yii\web\Linkable;
use yii\helpers\Url;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;

/**
 * Country Model
 *
 * @author Budi Irawan <deerawan@gmail.com>
 */
class Member extends ActiveRecord implements IdentityInterface //\common\models\Member
{
    const STATUS_DELETED = -1;
    const STATUS_INACTIVE = 0;
    const STATUS_ACTIVE = 1;

    private static $users = [
        '100' => [
            'id' => '100',
            'username' => 'admin',
            'password' => 'admin',
            'authKey' => 'test100key',
            'accessToken' => '100-token',
        ],
        '101' => [
            'id' => '101',
            'username' => 'demo',
            'password' => 'demo',
            'authKey' => 'test101key',
            'accessToken' => '101-token',
        ],
    ];
    public static function findIdentityByAccessTokenByArray($token, $type = null)
    {
        foreach (self::$users as $user) {
            if ($user['accessToken'] === $token) {
                return new static($user);
            }
        }

        return null;
    }
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%onramp_member}}';
    }

    public static function findIdentityByAccessToken($token, $type = null)
    {
        return static::findOne(['access_token' => $token]);
    }

    /**
     * @inheritdoc
     */
    public static function findIdentity($id)
    {
        return static::findOne(['id' => $id]);
    }

    /**
     * @inheritdoc
     */
    public function getId()
    {
        return $this->getPrimaryKey();
    }

    /**
     * @inheritdoc
     */
    public function getAuthKey()
    {
        return $this->auth_key;
    }

    /**
     * @inheritdoc
     */
    public function validateAuthKey($authKey)
    {
        return $this->getAuthKey() === $authKey;
    }

    /**
     * @brief ��������
     * @param bool $data        ��������
     */
    public static function insertData(array $data=array())
    {
        $db = \Yii::$app->db;
        if(!is_array($data) || empty($data)) return false;
        $result = $db->createCommand()->insert(self::tableName(), $data)->execute();

        if($result) {
            return  true;
        }
        return false;
    }


    /**
     * @brief ��������
     * @param bool $data        ��������
     * @param string $where     ��������
     */
    public static function updateData(array $data=array(), $where='')
    {
        $db = \Yii::$app->db;
        if(!is_array($data) || empty($data)) return false;
        if(empty($where) || $where == '') return false;

        $result = $db->createCommand()->update(self::tableName(), $data, $where)->execute();
        return $result;
    }


    /**
     * @brief ɾ������
     * @param $where string     ɾ������
     */
    public static function deleteData($where='')
    {
        $db = \Yii::$app->db;
        if(empty($where) || $where == '') return false;

        $result = $db->createCommand()->delete(self::tableName(), $where)->execute();
        return $result;
    }


}
