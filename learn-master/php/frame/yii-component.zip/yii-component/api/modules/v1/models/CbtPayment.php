<?php
/**
 * Created by PhpStorm.
 * User: peng
 * Date: 2015/12/1
 * Time: 11:33
 * Description: 与上海跨境电子商务进口服务平台对接
*/
namespace api\modules\v1\models;
use yii;
use yii\httpclient\Client;

class CbtPayment
{
    // 由东方支付获取相关私钥信息
    private $userInfo = array(
        'private_key' => 'ds12345'
    );

    // 申报相关接口
    private $goodsApply = "http://dev.www.yiiadvanced.com/index.php?r=applic/goodsapply";
    //private $goodsApply = "http://10.1.1.1/cboi/order/cargolist.htm";
    private $orderApply = "http://dev.www.yiiadvanced.com/index.php?r=applic/orderapply";
    private $sellerApply = "http://dev.www.yiiadvanced.com/index.php?r=applic/sellerapply";
    private $brandApply = "http://dev.www.yiiadvanced.com/index.php?r=applic/brandapply";

    // 查询接口
    private $sellerInquiry = "http://dev.www.yiiadvanced.com/index.php?r=inquiry/seller";
    private $brandInquiry = "http://dev.www.yiiadvanced.com/index.php?r=inquiry/brand";
    private $goodsInquiry = "http://dev.www.yiiadvanced.com/index.php?r=inquiry/goods";
    private $orderInquiry = "http://dev.www.yiiadvanced.com/index.php?r=inquiry/order";

    // 错误代码表
    private $errorCode = array(
        'ILLEGAL_SIGN' => '签名验证出错',
        'ILLEGAL_VERSION' => '无效版本号',
        'ILLEGAL_ARGUMENT' => '参数不正确',
        'HASH_NO_PRIVILEGE' => '没有权限访问该服务',
        'ILLEGAL_PARTNEr' => '电商标识不正确',
        'OUT_ORDER_ID_EXIST' => '电商订单已经存在',
        'OUT_CARGO_CODE_EXISt' => '商品编号已存在',
        'TOTAL_CARGO_FEE_LESSEQUAL_ZERO' => '全部商品合计总金额小于等于 0',
        'TOTAL_FEE_LESSEQUAL_ZERO' => '支付总金额小于等于 0',
        'TOTAL_FEE_OUT_OF_RANGE' => '支付总金额超出范围',
        'ILLEGAL_CARGO_CODE' => '非法商品信息, 商品未备案',
        'ILLEGAL_CARGO_NUM' => '非法商品集合数量, 无商品信息',
        'ILLEGAL_CARGO_FEE_PARAM' => '非法商品金额格式',
        'ILLEGAL_TOTAL_CARGO_FEE' => '非法商品总金额限制',
        'ILLEGAL_TAX_FEE_PARAM' => '非法行邮税金额格式',
        'ILLEGAL_RAY_FEE_PARAM' => '非法支付金额格式',
        'ILLEGAL_SENDER_COUNTRY' => '非法商品发件地国家或地区',
        'ILLEGAL_PAY_METHOD' => '非法支付方式',
        'ILLEGAL_ORDER_CARGO_TYPE' => '订单和商品业务类型不一致',
        'ILLEGAL_CUSTOM_DEC_CO' => '非法海关进境申报企业',
        'ILLEGAL_CLIENT_IP' => '客户端 IP 地址无权访问服务',
        'SYSTEM_ERROR' => '系统错误'
    );

    // 查询状态代码表
    private $code = array(
        'NO_ORDER' => '无此订单',
        'ORDER_UNDECLARED' => '订单未申报',
        'ORDER_APPROVING' => '订单审核中',
        'ORDER_AUDIT_SUCCESS' => '订单申报成功',
        'ORDER_AUDIT_FAILURE' => '订单申报失败',
        'ORDER_CLEARANCE' => '通关放行',
        'NO_CARGO' => '无此商品',
        'CARGO_UNDECLARED' => '商品未申报',
        'CARGO_APPROVING' => '商品审核中',
        'CARGO_AUDIT_SUCCESS' => '商品备案成功',
        'CARGO_AUDIT_FAILURE' => '商品案失败'
    );

    // 币种
    private $curency = array(
        'CNY' => '人民币',
        'USD' => '美元',
        'EUR' => '欧元',
        'GBP' => '英镑',
        'JPY' => '日元',
        'HKD' => '港币',
        'SGD' => '新加坡元'
    );

    // 海关代码
    private $customs = array(
        '2244' => '浦东机场',
        '2216' => '浦东自贸',
        '2249' => '洋山自贸',
        '2218' => '外高桥自贸'
    );

    // 物流申报企业代码
    private $logistics = array(
        'FEDEX' => '联邦快递',
        'DNJ' => '明邦运通',
        'SF' => '顺丰速运',
        'UPS' => '联全包裹',
        'TNT' => '天地国际运输代理',
        'DHL' => 'DHL 空运服务',
        'SJL' => '上海捷利货运',
        'YDH' => '上海义达国际物流',
        'OCS' => '欧西爱司物流',
        'WS' => '上海威盛报关',
        'SHF' => '中外运泓丰国际物流',
        'QHT' => '上海全行通国际物流'
    );

    // 支付方式
    private $payment = array(
        'EASIPAY' => '东方支付',
        'VISA' => 'VISA',
        'MASTER' => 'MASTER'
    );

    /**
     * 商品申报
     */
    public function goods($arr){
        // cargofactoryDate 出厂日期 可为空
        // copGNo 货号 materialID 物资序号 beianUnit 申报单位 beianQty 申报数量 直邮进口时可为空
        $goodsArray = array(
            'cargoCode' => $arr['code'], // 商品编号
            'cargoBrand' => $arr['brand'], // 商品品牌
            'cargoNameCh' => $arr['nameCh'], // 商品中文名
            'cargoNameEh' => $arr['nameEh'], // 商品英文名
            'cargoModel' => $arr['model'], // 型号
            'cargoSpec' => $arr['spec'], // 规格
            'cargoPlace' => $arr['place'], // 产地
            'cargoFunction' => $arr['function'], // 功能
            'cargoPurpose' => $arr['purpose'], // 用途
            'cargolngredient' => $arr['lngredient'], // 成份
            'cargoFactoryDate' => $arr['factoryDate'], // 出厂日期
            'cargoUnit' => $arr['unit'], // 单位 (计税单位)
            'cargoUnitNum' => $arr['unitNum'], // 单位数量
            'cargoPrice' => $arr['price'], // 单位 (人民币)
            'cargoGrossWT' => $arr['grossWT'], // 毛重 KG
            'cargoNetWT' => $arr['netWT'], // 净重 KG
            'serverType' => $arr['serverType'], // 业务类型 S01 直邮进口 S02 保税进口
            'customsCode' => $arr['customsCode'], // 申报关区
            'copGNo' => $arr['copGNo'], // 货号
            'materialID' => $arr['materialID'], // 物资序号
            'beianUnit' => $arr['beianUnit'], // 申报单位
            'beianQty' => $arr['beianQty'] // 申报数量
        );

        $data = array(
            'cargoes' => $goodsArray, // 商品信息
            'operationCode' => '', // 操作编码
            'spt' => '' // 扩展
        );

        $response = $this->response($data, $this->goodsApply);

        if ($response->status = "SUCCESS") {
            echo '调用成功';
        } else {
            echo '调用失败';
        }

    }

    /**
     * 基本数据
     */
    private function basicData(){
//        return array(
//            'verson' => 'v1.2',
//            'commitTime' => date('YmdHis'),
//            'coName' => '上海道领',
//            'coCode' => '企业代码', // 由平台分配
//            'serialNumber' => '流水号',
//        );

        return array(
            'verson' => 'v1.2', // 网关版本
            'commitTime' => date('YmdHis'), // 提交时间
            'srcNCode' => '上海道领', // 代理商户代码 由平台分配
            'coCode' => '企业代码', // 由平台分配
            'tradeCode' => '223464', // 企业备案编号
            'serialNumber' => '流水号',
        );
    }

    /**
     * 拼装申报数据并返回响应结果
     * $data 原生数据
    */
    private function response($data, $url){
        $basic = $this->basicData();

        $array = array_merge($basic, $data);
        $EData = json_encode($array); // 原生数据
        $SignMsg = md5($EData.$this->userInfo['private_key']); // 签名数据
        $EData = urlencode($EData);
        $client = new Client();
        $response = $client->createRequest()
            ->setMethod('post')
            ->setUrl($url)
            ->setData(['EData' => $EData, 'SignMsg' => $SignMsg])
            ->send();

        if ($response->isOk) {
            $res = json_decode($response->content);
            return $res;
        }
    }

    /**
     * 商户申报
     */
    public function seller($arr){
        $response = $this->response($arr, $this->sellerApply);
        echo "<pre>";
        var_dump($response);

        if ($response->status = "SUCCESS") {
            // 向数据库中添加备案号
            echo '调用成功';
        } else {
            echo '调用失败';
        }
    }

    /**
     * 品牌申报
     */
    public function brand($arr){
        $response = $this->response($arr, $this->brandApply);

        if ($response->status = "SUCCESS") {
            echo '调用成功';
        } else {
            echo '调用失败';
        }
    }

    /**
     * 订单申报
     */
    public function order($arr){
        $response = $this->response($arr, $this->orderApply);

        if ($response->status = "SUCCESS") {
            echo '调用成功';
        } else {
            echo '调用失败';
        }
    }

    /**
     * 查询数据
    */
    public function inquiryData($declaraNo){
        return array(
            'version' => 'v1.2',
            'coCode' => '111', // 企业代码
            'declaraNo' => $declaraNo
        );
    }

    /**
     * 商户申报信息查询
    */
    public function sellerInquiry($declaraNo) {
        $res = $this->inquiry($declaraNo, $this->sellerInquiry);
        if ($res->status == 1) {
            echo "查询成功";
        } else {
            echo "查询失败";
        }
    }

    /**
     * 品牌申报信息查询
     */
    public function brandInquiry($declaraNo) {
        $res = $this->inquiry($declaraNo, $this->brandInquiry);
        if ($res->status == 1) {
            echo "查询成功";
        } else {
            echo "查询失败";
        }
    }

    /**
     * 商品申报信息查询
     */
    public function goodsInquiry($declaraNo) {
        $res = $this->inquiry($declaraNo, $this->goodsInquiry);
        if ($res->status == 1) {
            echo "查询成功";
        } else {
            echo "查询失败";
        }
    }

    /**
     * 订单申报信息查询
     */
    public function orderInquiry($declaraNo) {
        $res = $this->inquiry($declaraNo, $this->orderInquiry);
        if ($res->status == 1) {
            echo "查询成功";
        } else {
            echo "查询失败";
        }
    }

    /**
     * 信息查询
    */
    private function inquiry($declaraNo, $url){
        $data = $this->inquiryData($declaraNo);
        $EData = json_encode($data);

        $client = new Client();
        $response = $client->createRequest()
            ->setMethod('get')
            ->setUrl($url)
            ->setData(['EData'=>$EData])
            ->send();
        if ($response->isOk) {
            $res = json_decode($response->content);
            return $res;
        } else {
            return "fail";
        }
    }


}