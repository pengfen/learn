<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/11
 * Time: 14:05
 * @file PushMessage.php
 * @brief 公共函数类
 */
namespace api\modules\v1\models;

use Yii;

use yii\rest\ActiveController;
use yii\web\Response;
use yii\filters\auth\HttpBasicAuth;
use yii\helpers\ArrayHelper;
use yii\filters\auth\CompositeAuth;
use yii\filters\auth\HttpBearerAuth;
use yii\filters\auth\QueryParamAuth;
use yii\filters\AccessControl;
use yii\data\ActiveDataProvider;
use yii\filters\ContentNegotiator;
use yii\filters\RateLimiter;
use yii\filters\VerbFilter;

//消息推送
class PushMessage{
    var $appkey = "";
    var $appid = "";
    var $mastersecret = "";
    var $host = "";

    public function pushMessageToSingle($cid = null,$message,$osname)
    {
        $rep = '';
//        $lib_google_base = Yii::getAlias("@api/modules/v1/models/pushmessage");
        $lib_google_base = Yii::getAlias("@vendor");
        include $lib_google_base . '/pushmessage/Igetui.php';

        $this->appkey = yii::$app->params['APPKEY'];
        $this->appid = yii::$app->params['APPID'];
        $this->mastersecret = yii::$app->params['MASTERSECRET'];
        $this->host = yii::$app->params['HOST'];
        $git = new \Igetui($this->host, $this->appkey, $this->mastersecret);

        //消息模版：
        // 1.TransmissionTemplate:透传功能模板
        // 2.LinkTemplate:通知打开链接功能模板
        // 3.NotificationTemplate：通知透传功能模板
        // 4.NotyPopLoadTemplate：通知弹框下载功能模板
        //通知弹框下载功能模板
//        $template = $git->IGtNotyPopLoadTemplateDemo($this->appid,$this->appkey);
//        $template = IGtLinkTemplateDemo($this->appid,$this->appkey,$message);
        if ($osname == "iOS") {
            //透传功能模板
            $template = $git->IGtTransmissionTemplateDemo($this->appid, $this->appkey, $message);
        } else {
            //通知透传功能模板
            $template = $git->IGtNotificationTemplateDemo($this->appid, $this->appkey, $message);
        }

        //个推信息体
        $message = $git->IGtgetSingleMessage($template);

        //接收方
        $target = $git->IGtgetTarget($this->appid, $cid);

        try {
            $rep = $git->pushMessageToSingle($message, $target);
        } catch (RequestException $e) {
            $requstId = e . getRequestId();
            $rep = $git->pushMessageToSingle($message, $target, $requstId);
        }
        if (is_array($rep) &&isset($rep)) {
            if(isset($rep['result'])){
                return true;
            }elseif($rep['code'] == 1){
                return false;
            }
        }
    }
}