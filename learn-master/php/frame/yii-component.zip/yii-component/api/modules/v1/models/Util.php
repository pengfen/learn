<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/11
 * Time: 14:05
 * @file util.php
 * @brief 公共函数类
 */
namespace api\modules\v1\models;

use Yii;
use yii\rest\ActiveController;
use yii\web\Response;
use yii\filters\auth\HttpBasicAuth;
use yii\helpers\ArrayHelper;
use yii\filters\auth\CompositeAuth;
use yii\filters\auth\HttpBearerAuth;
use yii\filters\auth\QueryParamAuth;
use yii\filters\AccessControl;
use yii\data\ActiveDataProvider;
use yii\filters\ContentNegotiator;
use yii\filters\RateLimiter;
use yii\filters\VerbFilter;
class Util{
    /**
     * 价格汇率转换
     * $type 1是人民币转美元，2是美元转人民币
     * @brief alisaxu 2015-11-11
     */
    public static function exchange($price,$type=2)
    {
        if(isset(yii::$app->params['goods_currency'])&&yii::$app->params['goods_currency']=='USD'){
            if($type==1&&isset(yii::$app->params['cnytousd'])){
                $rate = yii::$app->params['cnytousd'];
            }elseif($type==2&&isset(yii::$app->params['usdtocny'])){
                $rate = yii::$app->params['usdtocny'];
            }else{
                $rate = 1;
            }
            $price = round($rate*$price,2);
        }
        return $price;
    }
    /**
     * 图片地址转换成绝对路径
     * $url 要转换的图片
     * @brief alisaxu
    */
    public static function absolute_path($url){
        return yii::$app->params['serverName'].'/'.$url;
    }
    /**
     * 将字符串切割成数组
     * $str 切割的字符串
     * $char 标志字符
     * @brief alisaxu
    */
    public static function explode($str,$char=","){
        return explode($char,$str);
    }
    /**
     * 将数组拼接成字符串
     * $str 返回字符串
     * $arr 拼接的数组
     * @brief alisaxu
     */
    public static function joinStr($arr=array(),$char=","){
        return implode($char,$arr);
    }
    /**
     * 商品价格格式化
     * @param $price float 商品价
     * @return float 格式化后的价格
     */
    public static function priceFormat($price)
    {
        // ceil($price);
        return number_format(round($price));//千分位
    }
    /**
     * 商品价格格式化
     * @param $price float 商品价
     * @return float 格式化后的价格
     */
    public static function priceRound($price)
    {
        return round($price);//千分位
    }
    /**
     * 将商品规格的图片转换为绝对路径
     * @param $str 需要转换的图片字符串
     * @return $arr 规格数组
     * @brief alisaxu 2015-11-18
    */
    public static function spec_path($str = ''){
        $photoValue = str_replace("upload/",yii::$app->params['serverName']."/upload/",$str);
        $arr = self::explode($photoValue);
        return $arr;
    }

    /**
     * 获取邮件通知配置信息
     */
    public static function getNoticeMallConfig($key)
    {
        $returnData = array();
        $noticeMail = isset(yii::$app->params['noticeMail']) ? yii::$app->params['noticeMail'] : array();
        if(isset($noticeMail[$key]) && !empty($noticeMail[$key]))
        {
            $returnData = $noticeMail[$key];
        }
        return $returnData;
    }
    /**
     * 合并购物车的商品和货品信息
    */
    public static function arrayCart($cartInfo=array(),$cartOldInfo=array()){
        $cartNewInfo = array();
        $arrayKey = array_keys(unserialize($cartInfo['content']))+array_keys(unserialize($cartOldInfo['content']));
        foreach($arrayKey as $key=>$value){
            if(isset(unserialize($cartInfo['content'])[$value]) && isset(unserialize($cartOldInfo['content'])[$value])){
                $ar2 = unserialize($cartInfo['content'])[$value];
                $ar1 = unserialize($cartOldInfo['content'])[$value];
                $cartNewInfo[$value] = self::arrayMerage($ar1,$ar2);
            }elseif(isset(unserialize($cartInfo['content'])[$value]) && !isset(unserialize($cartOldInfo['content'])[$value])){
                $cartNewInfo[$value] = unserialize($cartInfo['content'])[$value];
            }elseif(!isset(unserialize($cartInfo['content'])[$value]) && isset(unserialize($cartOldInfo['content'])[$value])){
                $cartNewInfo[$value] = unserialize($cartOldInfo['content'])[$value];
            }
        }
        return $cartNewInfo;
    }
    /**
     * 合并两个数组(键相同值相加，键不相同追加)
     * @param ar1 数组1
     * @param ar2 数组2
     * @return $res 返回数组
    */
    public static function arrayMerage($ar1=array(),$ar2=array()){
        $res = array();
        $key2 = array_keys($ar2);
        $key1 = array_keys($ar1);
        $key = array_merge($key2,$key1);
        foreach($key as $k=>$v){
            if(isset($ar1[$v]) && isset($ar2[$v])){
                $res[$v] = $ar1[$v] + $ar2[$v];
            }elseif(isset($ar1[$v]) && !isset($ar2[$v])){
                $res[$v] = $ar1[$v];
            }elseif(isset($ar2[$v]) && !isset($ar1[$v])){
                $res[$v] = $ar2[$v];
            }
        }
        return $res;
    }
    /**
     * @brief MD5散列加密方式
     * $param String 要md5加密的数据
     * @return String md5加密后的数据
    */
    public static function md5($str){
        return md5($str);
    }
    /**
     * @brief 获取网站根路径
     * @param  string $protocol 协议  默认为http协议，不需要带'://'
     * @return String $baseUrl  网站根路径
     *
     */
    public static function getHost($protocol='http')
    {
        $host	 = isset($_SERVER['HTTP_X_FORWARDED_HOST']) ? $_SERVER['HTTP_X_FORWARDED_HOST'] : (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
        $baseUrl = $protocol.'://'.$host;
        return $baseUrl;
    }
    /**
     * 获取购物车商品数量和时间戳
     * @param $str  数量以及时间戳的字符串
    */
    public static function getNumTime($str = "")
    {
        // 获取值
        $count = $time = 0;
        $array = !empty($str) ? Util::explode($str,'_') : array();

        // 数据处理
        if(is_array($array)){
            $count  = isset($array[0]) ? intval($array[0]) : 0;
            $time   = isset($array[1]) ? intval($array[1]) : 0;
        }

        // 返回数据
        return array(
            'count' => $count,
            'time'  => $time
        );
    }

    /**
     * 创建邀请码信息
     */
    public static function createInvit()
    {
        $name = '';
        for($i = 1; $i <= 8; $i ++){
            $name .= strtoupper(chr(rand(65, 90)));
        }

        // 检测邀请码唯一性
        $invitTB = Invitation::tableName();
        $res = Invitation::selectOne("SELECT * FROM {$invitTB} WHERE name='{$name}'");
        if ($res) { // 重新生成邀请码
            $name = self::getInvit();
        } else {
            return $name;
        }
    }
}