<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/17
 * Time: 16:46
 * @file Mess.php
 * @brief 站内消息的管理
 */
namespace api\modules\v1\models;

use Yii;
use yii\rest\ActiveController;
use yii\web\Response;
use yii\filters\auth\HttpBasicAuth;
use yii\helpers\ArrayHelper;
use yii\filters\auth\CompositeAuth;
use yii\filters\auth\HttpBearerAuth;
use yii\filters\auth\QueryParamAuth;
use yii\filters\AccessControl;
use yii\data\ActiveDataProvider;
use yii\filters\ContentNegotiator;
use yii\filters\RateLimiter;
use yii\filters\VerbFilter;
use api\modules\v1\models\Goods_car;
use api\modules\v1\models\Goods;
use api\modules\v1\models\Products;
use api\modules\v1\models\Invitation;
use yii\db\Query;
/**
 * @brief alisaxu 购物车操作类
*/
class Cart extends ActiveController{
    /**
     * @brief alisaxu 将商品或者货品加入购物车
     * @param $array 加入购物车的商品信息
     * @param $type 加入类型 goods商品; product:货品;
     */
    public static function add($goodsInfo = array(),$user_id='',$type="clientId",$cid="", $cart_type=1){
        $cart_type = ($cart_type == 1) ? 1 : 2;
        if($goodsInfo){
            $goodsInfo = serialize($goodsInfo);
            $Goods_carTB = new Goods_car();
            $Goods_carTB->content = $goodsInfo;
            if($type == "clientId") {
                $Goods_carTB->clientId = $user_id;
            }elseif($type == "user_id"){
                $Goods_carTB->user_id = $user_id;
                $Goods_carTB->clientId = $cid;
            }
            $Goods_carTB->type = $cart_type;
            $Goods_carTB->create_time = date('Y-m-d H:i:s');
            $res = $Goods_carTB->save();
        }else{
            $res = 0;
        }
        return $res;
    }
    /**
     * $brief alisaxu 更新购物车中的商品内容
     * *@param $goodsInfo 加入购物车的商品信息
     * @param $type 加入类型 goods商品; product:货品;
     * @param $cartInfo 该用户的购物车内容
     * @param $user_id 用户ID
     */
    public static function update($cartInfo = array(),$user_id,$cid='', $cart_type=1){
        $cart_type = ($cart_type == 1) ? 1 : 2;
        if($cartInfo){
//            $goodsKey = array_keys($goodsInfo[$type]);
//
//            //购物车存在该类型的商品 goods商品; product:货品;
//            if(isset($cartInfo[$type]) && !empty($cartInfo[$type])) {
//                $cartKey = array_keys($cartInfo[$type]);
//                //购物车存在该件商品
//                if(in_array($goodsKey[0],$cartKey)){
//                    $cartInfo[$type][$goodsKey[0]] = $cartInfo[$type][$goodsKey[0]] + $goodsInfo[$type][$goodsKey[0]];
//                }
//                //购物车不存在该件商品
//                else{
//                    $cartInfo[$type] = $goodsInfo[$type]+$cartInfo[$type];
//                }
//            }
//            //购物车不存在该类型的商品 goods商品; product:货品;
//            else{
//                $cartInfo = array_merge($goodsInfo,$cartInfo);
//            }
            $insertInfo = serialize($cartInfo);
            $Goods_cartTB = Goods_car::findOne(['clientId' => $cid,'user_id' => NULL]);
            if($user_id){
                $Goods_cartTB = Goods_car::findOne(['user_id' => $user_id, 'type'=>$cart_type]);
            }
            $Goods_cartTB->content = $insertInfo;
            $res = $Goods_cartTB->save();
        }else{
            $res = 0;
        }
        return $res;
    }
    /**
     * 获取新加入购物车的数据
     * @param $cartInfo cartStruct
     * @param $gid 商品或者货品ID
     * @param $num 数量
     * @param $type goods 或者 product
     */
    public static function getUpdateCartData($cartInfo,$gid,$num,$type)
    {
        $gid = intval($gid);
        $num = intval($num);
        if($type != 'goods')
        {
            $type = 'product';
        }
        //获取基本的商品数据
        $goodsRow = self::getGoodInfo($gid,$type);
        if($goodsRow)
        {
            //购物车中已经存在此类商品
            if(isset($cartInfo[$type][$gid]))
            {
                if(preg_match("/_/",$cartInfo[$type][$gid])){
                    //获取购物车商品数量以及时间戳
                    $timeInfo = Util::getNumTime($cartInfo[$type][$gid]);
                    $buy_nums = $timeInfo['count'];
                    $time = $timeInfo['time'];
                }else{
                    $buy_nums = $cartInfo[$type][$gid];
                    $time = time();
                }

                $goodsNums = ($buy_nums + $num);
                if($goodsRow['store_nums'] < $goodsNums){
                    $result = ['is_Error'=>true,'message' =>'该商品库存不足','data'=>$goodsRow['store_nums'],'cartInfo'=>''];
                }elseif($goodsNums <= 0){
                    $result = ['is_Error'=>true,'message' =>'购物车数量不能小于1','data'=>$goodsRow['store_nums'],'cartInfo'=>''];
                }elseif($goodsRow['store_nums'] >= $goodsNums) {
                    $cartInfo[$type][$gid] = ($goodsNums).'_'.$time;
                    $result = ['is_Error' => false, 'message' => '符合标准', 'data' => $goodsRow['store_nums'], 'cartInfo' => $cartInfo];
                }
            }

            //购物车中不存在此类商品
            else
            {
                if($goodsRow['store_nums'] < $num)
                {
                    $result = ['is_Error'=>true,'message' =>'该商品库存不足','data'=>$goodsRow['store_nums'],'cartInfo'=>''];
                }elseif($goodsRow['store_nums'] >= $num && $num> 0) {
                    $cartInfo[$type][$gid] = $num.'_'.time();
                    $result = ['is_Error'=>false,'message' =>'符合标准','data'=>$goodsRow['store_nums'],'cartInfo'=>$cartInfo];
                }elseif($num <= 0) {
                    $result = ['is_Error'=>true,'message' =>'购买数量不能小于1','data'=>$goodsRow['store_nums'],'cartInfo'=>''];
                }
            }

        }
        else
        {
            $result = ['is_Error'=>true,'message' =>'该商品已下架','data'=>'','cartInfo'=>''];
        }
        return $result;
    }
    //根据 $gid 获取商品信息
    public static function getGoodInfo($gid, $type = 'goods')
    {
        $dataArray = array();

        //商品方式
        if($type == 'goods')
        {
            $dataArray = Goods::findOne(['id' => $gid,'is_del' => Goods::STATUS_INACTIVE]);
        }

        //货品方式
        else
        {
            $GoodsTB = Goods::tableName();
            $ProductsTB = Products::tableName();
            $query = new Query;
            $query->select(['*'])
                ->from($ProductsTB . 'AS p')
                ->leftJoin($GoodsTB . 'AS g', 'p.goods_id=g.id')
                ->where('p.id = ' . $gid . ' and g.is_del = '.Goods::STATUS_INACTIVE);
            $dataArray = $query->one();
        }
        return $dataArray;
    }
    /**
     * @brief alisaxu 2015-11-19 处理当前的购物车信息
     * @param $content 购物车内容
     * @return array : [goods]=>array( ['id']=>商品ID , ['data'] => array( [商品ID]=>array ([name]商品名称 , [img]图片地址 , [sell_price]价格, [count]购物车中此商品的数量 ,[type]类型goods,product , [goods_id]商品ID值 ) ) ) ,
     * [product]=>array( 同上 ) , [count]购物车商品和货品数量 , [sum]商品和货品总额 ;
    */
    public static function cartFormat($content = array()){
        $result = array();
        $goodsIdArray = array();
        $result['count'] = 0;
        if($content){
            //处理商品数据
            if(isset($content['goods']) && !empty($content['goods'])){
                $goodsIdArray = array_keys($content['goods']);
                $result['goods']['id'] = $goodsIdArray;
                $result['count'] = 0;
                $result['kind'] = 0;
                foreach($goodsIdArray as $gid){
                    //获取购物车的商品数量以及时间戳
                    $timeInfo = Util::getNumTime($content['goods'][$gid]);
                    $result['goods']['data'][$gid] = array(
                        'id'       => $gid,
                        'type'     => 'goods',
                        'goods_id' => $gid,
                        'count'    => $timeInfo['count'],
                        'time'     => $timeInfo['time'],
                    );
                    //购物车中的数量累加
                    $result['count'] += $timeInfo['count'];
                }
            }
            //处理货品数据
            if(isset($content['product'])&& !empty($content['product'])){
                $productKey = array_keys($content['product']);
                $result['product']['id'] = $productKey;
                $productInfo = Products::find()->where(['in','id',$productKey])->asArray()->all();
                if($productInfo){
                    foreach($productInfo as $proVal){
                        //获取购物车的货品数量以及时间戳
                        $timeInfo = Util::getNumTime($content['product'][$proVal['id']]);
                        $result['product']['data'][$proVal['id']] = array(
                            'id'         => $proVal['id'],
                            'type'       => 'product',
                            'goods_id'   => $proVal['goods_id'],
                            'count'      => $timeInfo['count'],
                            'time'       => $timeInfo['time'],
                            'sell_price' => $proVal['sell_price'],
                            'market_price' => $proVal['market_price'],
                            'store_nums' => $proVal['store_nums'],
                            'weight' => $proVal['weight'],
                            'freightPrice' => $proVal['freightPrice'],
                            'real_market_price' => $proVal['real_market_price'],
                            'cost_price' => $proVal['cost_price'],
                            'goods_no' => $proVal['products_no'],
                        );
                        $spec_array = json_decode($proVal['spec_array']);
                        foreach($spec_array as $key =>$specVal){
                            if($specVal->type == 2){
                                $spec_array[$key]->value = Util::spec_path($specVal->value);
                            }
                        }
                        $result['product']['data'][$proVal['id']]['spec_array'] = $spec_array;
                        if(!in_array($proVal['goods_id'],$goodsIdArray))
                        {
                            $goodsIdArray[] = $proVal['goods_id'];
                        }
                        //购物车中的种类数量累加
                        $result['count'] += $timeInfo['count'];
                    }
                }
            }
            //获取商品或者货品的图片品牌等信息
            $result['sum'] = 0;
            if($goodsIdArray){
                $goodsInfo = Goods::find()->where(['in','id',$goodsIdArray])->asArray()->all();
                foreach($goodsInfo as $goodsVal){
                    $goodsArray[$goodsVal['id']] = $goodsVal;
                }
                if(isset($content['goods']) && !empty($content['goods']) && isset($result['goods']['data']) && !empty($result['goods']['data'])) {
                    foreach ($result['goods']['data'] as $key => $val) {
                        if($goodsArray[$val['goods_id']]['img']) {
                            $result['goods']['data'][$key]['img'] = Util::absolute_path($goodsArray[$val['goods_id']]['img']);
                        }else{
                            $result['goods']['data'][$key]['img'] = $goodsArray[$val['goods_id']]['img'];
                        }
                        $result['goods']['data'][$key]['name'] = $goodsArray[$val['goods_id']]['name'];
                        $result['goods']['data'][$key]['orginCountry'] = $goodsArray[$val['goods_id']]['orginCountry'];
                        $result['goods']['data'][$key]['store_nums'] = $goodsArray[$val['goods_id']]['store_nums'];
                        $result['goods']['data'][$key]['sell_price'] = $goodsArray[$val['goods_id']]['sell_price'];
                        $result['goods']['data'][$key]['market_price'] = $goodsArray[$val['goods_id']]['market_price'];
                        $result['goods']['data'][$key]['cost_price'] = $goodsArray[$val['goods_id']]['cost_price'];
                        $result['goods']['data'][$key]['lowest_price'] = $goodsArray[$val['goods_id']]['lowest_price'];
                        $result['goods']['data'][$key]['brand_id'] = $goodsArray[$val['goods_id']]['brand_id'];
                        $result['goods']['data'][$key]['spec_array'] = "";
                        $result['goods']['data'][$key]['weight'] = $goodsArray[$val['goods_id']]['weight'];
                        $result['goods']['data'][$key]['freightPrice'] = $goodsArray[$val['goods_id']]['freightPrice'];
                        $result['goods']['data'][$key]['real_market_price'] = $goodsArray[$val['goods_id']]['real_market_price'];
                        $result['goods']['data'][$key]['custom_price'] = $goodsArray[$val['goods_id']]['custom_price'];
                        $result['goods']['data'][$key]['if_price'] = $goodsArray[$val['goods_id']]['if_price'];
                        $result['goods']['data'][$key]['delivery_type'] = $goodsArray[$val['goods_id']]['delivery_type'];
                        $result['goods']['data'][$key]['goods_no'] = $goodsArray[$val['goods_id']]['goods_no'];
                        $result['goods']['data'][$key]['seller_goods_no'] = $goodsArray[$val['goods_id']]['seller_goods_no'];
                        $result['goods']['data'][$key]['seller_id'] = $goodsArray[$val['goods_id']]['seller_id'];

                        //购物车中的金额累加
                        $result['sum'] += $goodsArray[$val['goods_id']]['sell_price'] * $val['count'];
                    }
                }

                if(isset($content['product'])&& !empty($content['product']) && isset($result['product']['data']) && !empty($result['product']['data'])) {
                    foreach ($result['product']['data'] as $key => $val) {
                        if($goodsArray[$val['goods_id']]['img']) {
                            $result['product']['data'][$key]['img'] = Util::absolute_path($goodsArray[$val['goods_id']]['img']);
                        }else{
                            $result['product']['data'][$key]['img'] = $goodsArray[$val['goods_id']]['img'];
                        }
                        $result['product']['data'][$key]['name'] = $goodsArray[$val['goods_id']]['name'];
                        $result['product']['data'][$key]['orginCountry'] = $goodsArray[$val['goods_id']]['orginCountry'];
                        $result['product']['data'][$key]['brand_id'] = $goodsArray[$val['goods_id']]['brand_id'];
                        $result['product']['data'][$key]['custom_price'] = $goodsArray[$val['goods_id']]['custom_price'];
                        $result['product']['data'][$key]['lowest_price'] = $goodsArray[$val['goods_id']]['lowest_price'];
                        $result['product']['data'][$key]['if_price'] = $goodsArray[$val['goods_id']]['if_price'];
                        $result['product']['data'][$key]['delivery_type'] = $goodsArray[$val['goods_id']]['delivery_type'];
                        $result['product']['data'][$key]['seller_goods_no'] = $goodsArray[$val['goods_id']]['seller_goods_no'];
                        $result['product']['data'][$key]['seller_id'] = $goodsArray[$val['goods_id']]['seller_id'];

                        //购物车中的金额累加
                        $result['sum'] += $result['product']['data'][$key]['sell_price'] * $val['count'];
                    }
                }
            }
            $result['kind'] = count($goodsIdArray);
        }
        return $result;
    }
    /**
     * @brief alisxu 获取当前的购物车信息
     * @param $goods_id 删除的商品或者货品ID
     * @param $type 删除的类型 goods 或者 product
     * @param $user_id 用户ID
     * @param $type 1：购物车  2：邀请马车
    */
    public static function Getmycart($goods_id,$type = 'goods',$user_id,$cid, $cart_type=1){
        $cart_type = ($cart_type == 1) ? 1 : 2;
        if($user_id) {
            $cartInfo = Goods_car::find()->where(['user_id' => $user_id, 'type'=>$cart_type])->one();
        }else{
            $cartInfo = Goods_car::find()->where(['clientId' => $cid,'user_id' => Null,'type' => $cart_type])->one();
        }
        if($cartInfo){
            $cartInfo = unserialize($cartInfo['content']);
            if(!empty($cartInfo[$type][$goods_id]) && isset($cartInfo[$type][$goods_id])){
                if(count($cartInfo[$type]) == 1){
                    unset($cartInfo[$type]);
                }else{
                    unset($cartInfo[$type][$goods_id]);
                }
                return $cartInfo;
            }else{
                return false;
            }
        }
    }
    /**
     * @brief alisaxu 购物车结算时的购物车信息
     * @param $productIds 货品ID字符串
     * @param $goodIds 商品ID字符串
     * @param $data 购物车信息
    */
    public static function Getbalance($productIds = "",$goodIds = "",$data){
        if($data){
            $cartValue = unserialize($data['content']);
            if(is_array($cartValue)){
                $productIdArray = explode(",",$productIds);
                $goodIdArray = explode(",",$goodIds);
                //指定商品提交
                if(!empty($productIds)){
                    foreach($cartValue["product"] as $key => $val){
                        if(!in_array($key,$productIdArray)){
                            unset($cartValue["product"][$key]);
                        }
                    }
                }else if(empty($productIds) && !empty($goodIds)){
                    unset($cartValue["product"]);
                }
                if(!empty($goodIds)){
                    foreach($cartValue["goods"] as $key => $val){
                        if(!in_array($key,$goodIdArray)){
                            unset($cartValue["goods"][$key]);
                        }
                    }
                }else if(empty($goodIds) && !empty($productIds)){
                    unset($cartValue["goods"]);
                }
                return Cart::cartFormat($cartValue);
            }
        }
    }
    /**
     * 删除已经提交的商品\
     * @param $goods 商品
     * @param $product 货品
     * @brief alisaxu 2015-11-26
    */
    public static function RemoveCartinfo($goods = '',$product = '',$user_id){
        $res = 0;
        //购物车信息
        $cartInfo = Goods_car::findOne(['user_id'=>$user_id])['content'];
        $cartInfo = unserialize($cartInfo);
        if($goods){
            $goods = Util::explode(trim($goods,','));
            $goods = array_flip(array_flip($goods));
        }
        if($product){
            $product = Util::explode(trim($product,','));
            $product = array_flip(array_flip($product));
        }
        //指定商品删除
        if(!empty($product)){
            foreach($cartInfo["product"] as $key => $val){
                if(in_array($key,$product)){
                    if(count($cartInfo["product"]) == 1){
                        unset($cartInfo["product"]);
                    }
                    unset($cartInfo["product"][$key]);
                }
            }
        }else if(empty($productIds) && !empty($goodIds)){
            unset($cartInfo["product"]);
        }
        //指定货品删除
        if(!empty($goods)){
            foreach($cartInfo["goods"] as $key => $val){
                if(in_array($key,$goods)){
                    if(count($cartInfo["goods"]) == 1){
                        unset($cartInfo["goods"]);
                    }
                    unset($cartInfo["goods"][$key]);
                }
            }
        }else if(empty($goodIds) && !empty($productIds)){
            unset($cartInfo["goods"]);
        }
        $goods_carTB = Goods_car::findOne(['user_id' => $user_id]);
        if(count($cartInfo) == 0){
            $res = $goods_carTB->delete();
        }else{
            $goods_carTB->content = serialize($cartInfo);
            $res = $goods_carTB->update();
        }
        if($res = 1){
            return true;
        }else{
            return false;
        }
    }
    /**
     * 根据商品id 来获取对应货品id
     * @param $gid 商品id
     * @param $str 参数规格字符串
     */
    public static  function getProduct($gid, $str){
        $strs = explode(",", trim($str, ',')); // 把字符串拼接为数组
        $arr1 = array();
        foreach ($strs as $k=>$v) { // 比对参数规格返回货品id
            $spec = explode(":", $v);
            $arr1[$spec[0]] = $spec[1];
        }

        $productInfo = Products::find()->where(["goods_id" =>$gid])->asArray()->all();

        foreach ($productInfo as $key=>$value) {
            $val = json_decode($value['spec_array']); // 获取当前参数规格
            $arr2 = array();
            foreach($val as $k=>$v) {
                $arr2[$v->name] = $v->value;
            }

            $arr3 = array_diff($arr1, $arr2); // 比较两数组
            if (empty($arr3)) {
                return $value['id'];
            }
        }
    }
    /**
     * 获取优惠码信息
     */
    public static function getInvitInfo($invitName)
    {
        if(empty($invitName)) return false;

        $invitationTB = Invitation::tableName();
        $query = new Query;
        $tokenRow = $query->select('*')->from($invitationTB)->where("name = '{$invitName}' and user_id=0")->one();    //  and status = 0
        if(!empty($tokenRow)){
            $goodsArr = json_decode($tokenRow['goods_array'], true);
            if(isset($goodsArr) && !empty($goodsArr)){
                $content        = self::getGoodsContent($goodsArr);
                $concession     = $tokenRow['concession'];
                $rebate         = isset($goodsArr['rebate']) ? $goodsArr['rebate'] : 0;                     // 设计师等级返利百分比
                $sell_price     = isset($goodsArr['sell_price']) ? $goodsArr['sell_price'] : 0;             // 销售总价
                $lowest_price   = isset($goodsArr['lowest_price']) ? $goodsArr['lowest_price'] : 0;         // 保底总价
                $invit_price    = ((($sell_price - $lowest_price) * $rebate / 100) * $concession) / 100;    // 邀请码优惠金额
            }

            return array(
                'id'            => $tokenRow['id'],
                'content'       => !empty($content) ? serialize($content) : '',
                'concession'    => $concession,
                'rebate'        => $rebate,
                'invit_price'   => $invit_price
            );
        }
    }


    /**
     * 总价增加邀请码优惠金额
     * @param $totalInfo
     * @param $invitInfo
     * @return mixed
     */
    public static function invitGoodsPrice($totalInfo, $invitInfo)
    {
        $real_payment   = isset($totalInfo['real_payment']) ? $totalInfo['real_payment'] : 0;
        $invit_price    = isset($invitInfo['invit_price']) ? $invitInfo['invit_price'] : 0;
        $totalInfo['invit_price']   = $invit_price;
        $totalInfo['real_payment']  = Util::priceFormat($real_payment-$invit_price);
        return $totalInfo;
    }
    /**
     * 处理多商品 多优惠码问题
     * @param $goods_ids_arr
     * @return mixed
     */
    public static function getGoodsArr($goods_ids)
    {
        if(empty($goods_ids)) return false;

        $goods_ids_arrTemp = array();
        $goods_ids_arr = explode('_', $goods_ids);
        foreach($goods_ids_arr as $idsK => $idsV){
            $goods_ids_value = explode('*',$idsV);
            if(isset($goods_ids_value[0]) && isset($goods_ids_value[1])){
                if(isset($goods_ids_arrTemp[$goods_ids_value[0]])){
                    $goods_ids_arrTemp[$goods_ids_value[0]] = intval($goods_ids_arrTemp[$goods_ids_value[0]])+intval($goods_ids_value[1]);
                }else{
                    $goods_ids_arrTemp[$goods_ids_value[0]] = intval($goods_ids_value[1]);
                }
            }
        }
        return $goods_ids_arrTemp;
    }


    /**
     * 解析商品参数
     * @param $arr
     * @return array
     */
    public static function getGoodsContent($arr)
    {
        $goods      = isset($arr['goods']) ? explode(',', $arr['goods']) : array();
        $product    = isset($arr['product']) ? explode(',', $arr['product']) : array();

        // 商品信息
        foreach($goods as $v){
            if(empty($v)) continue;
            $goodV = explode(':', $v);
            $goodsArr[$goodV[0]] = isset($goodV[1]) ? intval($goodV[1]) : 0;
        }

        // 货品信息
        foreach($product as $vv){
            if(empty($vv)) continue;
            $productV = explode(':', $vv);
            $productArr[$productV[0]] = isset($productV[1]) ? intval($productV[1]) : 0;
        }

        // 返回数据
        return array(
            'goods' => isset($goodsArr) ? $goodsArr : '',
            'product' => isset($productArr) ? $productArr : '',
        );
    }
    /**
     * 设计师返利
     * peng 15-11-11
     * @param $name 邀请码字符串
     */
    public static function invitRebate($user_id, $invit_id, $ordersStr='')
    {
        // 处理订单信息
        $ordersStr = implode(',', $ordersStr);

        // 修改邀请码表中的使用状态
        $invitName = Invitation::tableName();
        $invitData = array(
            'status' => 1,
            'use_time' => time(),
            'orders'=>json_encode($ordersStr, JSON_UNESCAPED_UNICODE),
            'user_id' => $user_id
        );
        Invitation::updateData($invitData, "id={$invit_id}");
    }
    /**
     * 获取购物车信息
     * @param $cartRow 该设备上的购物车信息
     * @param $cartOldInfo 不在该设备上登录时的购物车信息
     * @param $cartNowInfo 在该设备登录时的购物车信息
     * @return $cartInfo 购物车信息
    */
    public static function getCartInfo($cartRow,$cartOldInfo,$cartNowInfo,$user_id,$cid){
        $cartInfo = array();
        if(empty($cartNowInfo) && !empty($cartOldInfo) && !empty($cartRow)){
            $cartNewInfo = Util::arrayCart($cartRow,$cartOldInfo);
            $data = array('content' => serialize($cartNewInfo),'clientId' => $cid);
            $where = 'user_id = '.$user_id;
            $update_id = Goods_car::updateData($data,$where);
            if($update_id){
                $cartInfo = Goods_car::find()->where(['user_id' => $user_id,'type' => 1])->asArray()->one();
            }
        }elseif(!empty($cartNowInfo) && empty($cartRow)){
            $cartInfo = $cartNowInfo;
        }elseif(empty($cartNowInfo) && !empty($cartOldInfo) && empty($cartRow)){
            $cartInfo = $cartOldInfo;
            $cartOldInfo->clientId = $cid;
            $cartOldInfo->update();
        }elseif(empty($cartNowInfo) && empty($cartOldInfo) && !empty($cartRow)){
            $data = ['user_id' => $user_id,'clientId' => $cid,'content' => $cartRow['content'],'create_time' => date('y-m-d h:i:s'),'type' => 1];
            Goods_car::insertData($data);
            $cartInfo = $cartRow;
        }elseif(!empty($cartNowInfo) && !empty($cartRow)){
            $cartNewInfo = Util::arrayCart($cartRow,$cartNowInfo);
            $data = array('content' => serialize($cartNewInfo),'clientId' => $cid);
            $where = 'user_id = '.$user_id;
            $update_id = Goods_car::updateData($data,$where);
            if($update_id){
                $cartInfo = Goods_car::find()->where(['user_id' => $user_id,'type'=> 1])->asArray()->one();
            }
        }
        return $cartInfo;
    }


    /**
     * 获取邀请码( 需要插入数据库 )数据
     */
    public static function getInsertInvitData($cartInfo)
    {
        $goods = array('goods'=>'', 'product'=>'', 'rebate'=>0, 'sell_price'=>'', 'lowest_price'=>'', 'param'=>array());
        if(is_array($cartInfo) && isset($cartInfo['content'])){
            $goodsArr = unserialize($cartInfo['content']);

            // 商品
            if(isset($goodsArr['goods']) && !empty($goodsArr['goods']) && is_array($goodsArr['goods'])){
                foreach($goodsArr['goods'] as $key => $val) {
                    $goods['goods'] .= $key.':'.$val.',';
                }
                $goods['goods'] = trim($goods['goods'], ',');
            }

            // 货品
            if(isset($goodsArr['product']) && !empty($goodsArr['product']) && is_array($goodsArr['product'])){
                foreach($goodsArr['product'] as $key => $val) {
                    $goods['product'] .= $key.':'.$val.',';
                }
                $goods['product'] = trim($goods['product'], ',');
            }

            // 获取邀请码信息
            $invitaionData = Cart::getInvitationService($cartInfo);

            $goods['rebate']        = $invitaionData['design_rebate'];
            $goods['sell_price']    = $invitaionData['sell_price'];
            $goods['lowest_price']  = $invitaionData['lowest'];
            return $goods;
        }
        return false;
    }


    /**
     * 获取邀请马车生成信息信息
     */
    public static function getInvitationService($cartInfo)
    {
        $user_id = isset($cartInfo['user_id']) && !empty($cartInfo['user_id']) ? intval($cartInfo['user_id']) : 0;
        $content = isset($cartInfo['content']) && !empty($cartInfo['content']) ? unserialize($cartInfo['content']) : "";
        if (!empty($user_id) && !empty($content)) {
            // 获取邀请码车 销售价和保底价信息
            $goodsPriceData = self::getProductPrice($content);
            $sell_price     = $goodsPriceData['sell_price'];
            $lowest_price   = $goodsPriceData['lowest_price'];

            // 根据设计师 id 查询设计师的返利百分比
            $designTB       = Designer::tableName();
            $design_grade   = Designer_grade::tableName();
            $rebate         = Designer::selectOne("SELECT dg.rebate, d.grade FROM {$designTB} d LEFT JOIN {$design_grade} dg ON d.grade = dg.id WHERE d.user_id={$user_id}");
            if($rebate) {
                // 计算当前设计师等级最多可让利价格
                $section = (($sell_price - $lowest_price) * $rebate['rebate']) / 100;

                // 计算其他价格
                $returnData = array(
                    'design_rebate' => $rebate['rebate'],
                    'grade'         => $rebate['grade'],                                    // 等级信息
                    'section'       => Util::priceFormat($section),                       // 可支配空间
                    'concess'       => Util::priceFormat($section / 2),                   // 当前优惠价格
                    'rebate'        => Util::priceFormat($section / 2),                    // 设计师可获得返利
                    'realPrice'     => Util::priceFormat($sell_price - ($section / 2)), // 买家实际购买价
                    'lowest'        => Util::priceFormat($lowest_price),                       // 网站保底价
                    'sell_price'    => Util::priceFormat($sell_price)
                );

                return $returnData;
            }
        }

        return false;
    }


    /**
     * 获取并计算( 商品/货品 ) 销售价和保底价信息
     */
    public static function getProductPrice($goodsArr = array())
    {
        $sell_price = $lowest_price = 0;
        $goodList = $productList = $goodsNumArr = $productNumArr = array();
        if(is_array($goodsArr) && !empty($goodsArr)){
            $goodsID    = isset($goodsArr['goods']) ? self::getProductPriceID($goodsArr['goods']) : '';
            $productID  = isset($goodsArr['product']) ? self::getProductPriceID($goodsArr['product']) : '';

            // 获取商品信息
            if (!empty($goodsID)) {
                $goodsTB = Goods::tableName();
                $goodList = Goods::selectAll("SELECT id,sell_price, lowest_price FROM {$goodsTB} WHERE id in ({$goodsID})");

                $goodsNumArr = isset($goodsArr['goods']) && !empty($goodsArr['goods']) ? $goodsArr['goods'] : array();
            }

            // 获取货品信息
            if(!empty($productID)){
                $goodsTB        = Goods::tableName();
                $productsTB     = Products::tableName();
                $productList     = Goods::selectAll("SELECT pro.id,pro.sell_price, go.lowest_price FROM {$productsTB} pro LEFT JOIN {$goodsTB} go ON go.id = pro.goods_id WHERE pro.id in({$productID})");

                $productNumArr = isset($goodsArr['product']) && !empty($goodsArr['product']) ? $goodsArr['product'] : array();
            }

            // 数据合并
            $goodList       = array_merge($goodList, $productList);
            $goodsNumArr    = $goodsNumArr+$productNumArr;

//            print_r($goodList);
//            print_r($goodsNumArr);

            // 计算价格
            foreach($goodList as $key => $val){
                $sell_price += Util::priceRound(Util::exchange($val['sell_price'])) * $goodsNumArr[$val['id']];
                $lowest_price += Util::priceRound(Util::exchange($val['lowest_price'])) * $goodsNumArr[$val['id']];
            }
        }

        return array(
            'sell_price' => $sell_price,
            'lowest_price' => $lowest_price
        );
    }

    /**
     * 获取商品数组ID
     * @param array $idArr
     * @return string
     */
    public static function getProductPriceID($idArr = array())
    {
        if(is_array($idArr) && !empty($idArr)){
            return implode(',', array_keys($idArr));
        }
        return '';
    }

}