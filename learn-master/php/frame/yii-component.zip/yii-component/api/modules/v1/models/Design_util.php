<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/12/28
 * Time: 11:32
 */
namespace api\modules\v1\models;

use yii\web\Link;
use yii\web\Linkable;
use yii\helpers\Url;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;

/**
 * 设计师工具类
 * Class Design_util
 * @package api\modules\v1\models
 */
class Design_util{

    /**
     * 获取当前邀请码订单用户ID
     * @param int $order_id
     */
    static public function getInvitation($order_id=0)
    {
        $order_id = intval($order_id);
        if($order_id){
            $invitationTB = Invitation::tableName();
            $designInfo = Invitation::selectAll("SELECT * FROM {$invitationTB}");
            //print_r($designInfo);
            foreach($designInfo as $key=>$val) {
                $orders = explode(",", json_decode($val['orders'], true));
                foreach($orders as $value) {
                    $str = explode(":", $value); // 0 订单id 1 冻结金额 2 积分
                    if($str[0] == $order_id) {
                        $user_id = $val['user_id'];
                        break;
                    }
                }
            }
        }

        return isset($user_id) ? $user_id : 0;
    }







    // @peng 15-11-13 修改设计师金额
    static public function editDesignAmount($user_id, $id){
        // 根据用户id 查询出设计师id
        $invitationTB = Invitation::tableName();
        $designerTB = Designer::tableName();
        $sql = "SELECT iv.orders,iv.invit_amount,iv.name,de.user_id,de.point,de.grade,de.avail,de.user_pid,de.freezing FROM {$invitationTB} iv ";
        $sql .= " LEFT JOIN {$designerTB} de ON de.user_id=iv.design_id WHERE iv.user_id = '{$user_id}'";
        $designInfo = Invitation::selectAll($sql);

        $order = '';
        foreach($designInfo as $key=>$val) {
            $orders = explode(",", json_decode($val['orders'], true));
            foreach($orders as $value) {
                $str = explode(":", $value); // 0 订单id 1 冻结金额 2 积分
                if($str[0] == $id) {
                    // 更新设计师积分
                    $point = $val['point'] + round($str[2]);
                    $dataArray = array(
                        'point' => $point // 添加积分
                    );
                    $res = Designer::updateData($dataArray, "user_id={$val['user_id']}");
                    $order = $val['orders'].'#'.$val['invit_amount'].'#'.$val['user_id'];

                    if ($res) {
                        // 记录积分日志
                        self::pointLog($val['user_id'], round($str[2]), $point);

                        // 设计师是否升级
                        self::isUpgrade($val['user_id']);

                        if ($val['user_pid'] != 0){
                            // 给父级用户添加积分
                            $designerTB = Designer::tableName();
                            $parentInfo = Designer::selectOne("SELECT point FROM {$designerTB} WHERE user_id={$val['user_pid']}");
                            $point = $parentInfo['point'] + round($str[2]);
                            $data = array(
                                'point' => $point
                            );
                            Designer::updateData($data, "user_id={$val['user_pid']}");

                            // 记录积分日志
                            self::pointLog($val['user_pid'], round($str[2]), $point);

                            // 设计师是否升级
                            self::isUpgrade($val['user_pid']);
                        }
                    }

                    break;
                }
            }
        }

        // 改变带提现金额
        if(!empty($order)) {
            $name = explode("#", $order);

            $ids = self::getOrders($name[0]);

            // 修改待提现金额
            self::updateFreezing($ids, $name[1], $name[2]);
        }

    }

    /**
     * @peng 15-11-27 更新待提现金额
     */
    static public function getOrders($name) {
        $orders = explode(",", json_decode($name, true));
        $ids = "";
        foreach($orders as $value) {
            $str = explode(":", $value); // 0 订单id 1 冻结金额 2 积分
            $ids .= $str[0].',';
        }
        return rtrim($ids, ',');
    }

    /**
     * @peng 15-11-27 更新待提现金额
     */
    static public function updateFreezing($ids, $invit_amout, $design_id){
        if (!empty($ids)) {
            $orderTB = Order::tableName();
            $invitInfo = Order::selectAll("SELECT status FROM {$orderTB} WHERE id in ({$ids})");

            $flag = true;
            foreach($invitInfo as $key=>$val) {
                if ($val['status'] != 2) {
                    $flag = false;
                }
            }
            if ($flag == true) {
                // 修改可提现金额
                $designTB = Designer::tableName();
                $res = Designer::selectOne("SELECT freezing FROM {$designTB} WHERE user_id={$design_id}");

                $designArray = array(
                    'freezing' => abs($res['freezing'] + $invit_amout)
                );

                Designer::updateData($designArray, "user_id={$design_id}");
            }
        }
    }

    /**
     * @peng 15-11-18 添加积分日志记录
     */
    public function pointLog($user_id=0, $point=0, $total_point=0)
    {
        $user_id        = intval($user_id);
        $point          = intval($point);
        $total_point    = intval($total_point);
        if($user_id <= 0) return false;
        if($point <= 0) return false;
        if($total_point <= 0) return false;

        // 获取用户信息
//        $designTB = Designer::tableName();
//        $design = Designer::selectOne("SELECT * FROM {$designTB} where user_id={$user_id}");
//        if(!is_array($design) || empty($design)) return false;
//
//        // 设置数据
//        $total_point = intval($design['point'])+intval($point);
//        if($total_point <= 0) $total_point = 0;

        // 添加DB
        $data = array(
            'user_id'       => $user_id,
            'point'         => $point,
            'total_point'   => $total_point,
            'create_time'   => time(),
            'remark'        => "用户:{$user_id}, 获取积分：{$point} , 总积分：{$total_point}"
        );

        $result = Designer_point::insertData($data);

        if($result) return true;
        return false;

    }

    /**
     * @peng 15-11-18 判断是否升级
     */
    static public function isUpgrade($user_id){
        // 获取用户信息
        $designTB = Designer::tableName();
        $design = Designer::selectOne("SELECT * FROM {$designTB} WHERE user_id={$user_id}");

        // 判断是否可以升级
        $gradeTB = Designer_grade::tableName();
        $gradeInfo = Designer_grade::selectOne("SELECT * FROM {$gradeTB} WHERE id={$design['grade']}");
        if ($design['point'] > $gradeInfo['point']) {
            $data = array(
                'point' => 0,   //(abs($gradeInfo['point'] - $point)),
                'grade' => ($design['grade'] + 1)
            );
            Designer::updateData($data, "user_id={$user_id}");
        }
    }
}