<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/12
 * Time: 14:05
 * @file Order_class.php
 * @brief 订单相关函数类
 */
namespace api\modules\v1\models;

use Yii;
use yii\rest\ActiveController;
use yii\web\Response;
use yii\filters\auth\HttpBasicAuth;
use yii\helpers\ArrayHelper;
use yii\filters\auth\CompositeAuth;
use yii\filters\auth\HttpBearerAuth;
use yii\filters\auth\QueryParamAuth;
use yii\filters\AccessControl;
use yii\data\ActiveDataProvider;
use yii\filters\ContentNegotiator;
use yii\filters\RateLimiter;
use yii\filters\VerbFilter;
use api\modules\v1\models\Payment;
use api\modules\v1\models\Areas;
use api\modules\v1\models\Order_extend;
use api\modules\v1\models\Order;
use api\modules\v1\models\Goods;
use api\modules\v1\models\Seller;
use api\modules\v1\models\Push_track;
use api\modules\v1\models\Order_goods;
use yii\db\Query;
class Order_class{
    /**
     * 获取用户支付方式
     * $id  支付类型
     * @brief alisaxu 2015-11-12
    */
    public static function Getpaytype($id){
        if($id){
            $data = Payment::findOne([
                'id'=>$id,
                'status' => Payment::STATUS_INACTIVE,
            ]);
        }
        return $data;
    }
    /**
     * 获取订单状态
     * $orderRow 订单信息
     * @param $orderRow array('status' => '订单状态','pay_type' => '支付方式ID','distribution_status' => '配送状态','pay_status' => '支付状态')
     * @return int 订单状态值 0:未知; 1:未付款等待发货(货到付款); 2:等待付款(线上支付); 3:已发货(已付款); 4:已付款等待发货; 5:已取消; 6:已完成(已付款,已收货); 7:已退款; 8:部分发货(不需要付款); 9:部分退款(未发货+部分发货); 10:部分退款(已发货); 11:已发货(未付款);
     * @brief alisaxu
    */
    public static function GetorderStatus($orderRow){
        $orderRow['pay_status'] = isset($orderRow['pay_status']) ? $orderRow['pay_status'] : 0;
        //1,刚生成订单,未付款
        if($orderRow['status'] == 1)
        {
            //选择货到付款
            if($orderRow['pay_type'] == 0)
            {
                if($orderRow['distribution_status'] == 0)
                {
                    return 1;
                }
                else if($orderRow['distribution_status'] == 1)
                {
                    return 11;
                }
                else if($orderRow['distribution_status'] == 2)
                {
                    return 8;
                }
            }
            else if ($orderRow['pay_status'] == 2) {
                if ($orderRow['distribution_status'] == 3) {
                    return 13;
                } else {
                    return 12;
                }
            }
            //选择在线支付
            else
            {
                return 2;
            }

        }
        //2,已经付款
        else if($orderRow['status'] == 2)
        {
            if($orderRow['distribution_status'] == 0)
            {
                return 4;
            }
            else if($orderRow['distribution_status'] == 1)
            {
                return 3;
            }
            else if($orderRow['distribution_status'] == 2)
            {
                return 8;
                //配送状态为3，即定做商品已经完成
            }else if($orderRow['distribution_status'] == 3){
                return 4;
            }
        }
        //3,取消或者作废订单
        else if($orderRow['status'] == 3 || $orderRow['status'] == 4)
        {
            return 5;
        }
        //4,完成订单
        else if($orderRow['status'] == 5)
        {
            return 6;
        }
        //5,退款
        else if($orderRow['status'] == 6)
        {
            return 7;
        }
        //6,部分退款
        else if($orderRow['status'] == 7)
        {
            //发货
            if($orderRow['distribution_status'] == 1)
            {
                return 10;
            }
            //未发货
            else
            {
                return 9;
            }
        }
        return 0;
    }
    /**
     * 获取订单流程
     * @param $arr 订单信息
     * @return $data 订单流程数组
     * @brief alisaxu 2015-11-17
    */
    public static function order_state($arr=array()){
        $orderstate = array();
        if($arr) {
            $orderStatus = self::GetorderStatus($arr);
            if ($orderStatus) {
                if(in_array($orderStatus, array(2, 12, 13, 3, 4, 6))){
                    $orderstate[] = ['state' => '订单完成 等待付款'];
                }
                if(in_array($orderStatus, array(12, 13, 3, 4, 6))){
                    $pay_time = Order_extend::findOne(['order_id'=>$arr['id']]);
                    $orderstate[] = [ 'state' => '定金支付完成 等特商家准备商品', 'time' => $pay_time['pay_time']];
                }
                if(in_array($orderStatus, array(13, 3, 4, 6))){
                    $orderstate[] =[ 'state' => '商家商品准备完成 等待支付尾款'];
                }
                if(in_array($orderStatus, array(13, 3, 4, 6))){
                    $orderstate[] = [ 'state' => '支付尾款完成 等待商家发货','time' => $arr['pay_time']];
                }
                if(in_array($orderStatus, array(3, 6))){
                    $orderstate[] = [ 'state' => '海外商家已发货','time' => $arr['send_time']];
                }
                $orderdetail = Order_goods::findOne(['order_id' => $arr['id']]);
                if($orderdetail){
                    $push_track = Push_track::findOne(['ShipperOrderNo' => $orderdetail['ShipperOrderNo']]);
                    if($push_track &&(trim($push_track['TrackingContent']) != '支付成功')&&(trim($push_track['TrackingContent']) != '订单信息已收到')){
                        $orderstate[] = [ 'state' => $push_track['TrackingContent'],'time' => $push_track['TrackingTime']];
                    }
                }
                if($orderStatus == 6){
                    $orderstate[] = [ 'state' =>  '用户已签收 交易完成'];
                }
            }
        }
        return $orderstate;
    }
    /**
     * 获取订单状态问题说明
     * @param $statusCode int 订单的状态码
     * @return string 订单状态说明
     */
    public static function GetorderStatusText($statusCode)
    {
        $result = array(
            0 => '未知',
            1 => '等待发货',
            2 => '等待付款',
            3 => '商家已发货',
            4 => '等待发货',
            5 => '已取消',
            6 => '已完成',
            7 => '已退款',
            8 => '部分发货',
            9 => '部分发货',
            10=> '部分退款',
            11=> '已发货',
            12=>'已支付定金',
            13=>'准备货品完成'
        );
        return isset($result[$statusCode]) ? $result[$statusCode] : '';
    }
    /**
     * 获取status （1、生成订单 2、支付订单 3、取消订单 4、作废订单 5、完成订单 6、退款订单 7、部分退款订单）
     * $code 状态码
     * @brief alisaxu
    */
    public static function Getstatus($orderRow){
        $code = "";
        if($orderRow['status']){
            switch($orderRow['status']){
                case 1:
                    $code = "生成订单";
                    break;
                case 2:
                    $code = "支付订单";
                    break;
                case 3:
                    $code = "取消订单";
                    break;
                case 4:
                    $code = "作废订单";
                    break;
                case 5:
                    $code = "完成订单";
                    break;
                case 6:
                    $code = "退款订单";
                    break;
                case 7:
                    $code = "部分退款订单";
                    break;
            }
        }
        return $code;
    }
    //获取订单支付状态
    public static function GetOrderPayStatusText($orderRow)
    {
        if($orderRow['pay_status'] == 0)
        {
            return '未付款';
        }
        else if($orderRow['pay_status'] == 1)
        {
            return '已付款';
        }
        else if($orderRow['pay_status'] == 2) {
            return '已支付定金';
        }
        return '未知';
    }
    //获取订单配送状态
    public static function GetOrderDistributionStatusText($orderRow)
    {
        if($orderRow['status'] == 5)
        {
            return '已收货';
        }
        else if($orderRow['distribution_status'] == 1)
        {
            return '已发货';
        }
        else if($orderRow['distribution_status'] == 0||$orderRow['is_send']==0)
        {
            return '未发货';
        }
        else if($orderRow['distribution_status'] == 2)
        {
            return '部分发货';
        }
        else if($orderRow['distribution_status'] == 3) {
            return '准备发货';
        }
    }
    /**
     * 获取收货地址
     * $arr 省市区数组id
     * @brief alisaxu
    */
    public static function GetAreas($arr=array()){
        $result = array();
        if($arr){
            $areaData = Areas::find()->where(['in','area_id',$arr])->all();
            foreach($areaData as $key => $value)
            {
                $result[$value['area_id']] = $value['area_name'];
            }
        }
        return $result;
    }
    /**
     * 我的询价的状态
     * $arr 需要处理的数据
     * @brief alisaxu 2015-11-16
    */
    public static function reply_state($arr){
        if($arr){
            switch($arr['reply_state']){
                case 0:
                    $arr['reply_state'] = [$arr['reply_state'],'等待报价'];
                    break;
                case 1:
                    $arr['reply_state'] = [$arr['reply_state'],'已报价'];
                    break;
                case 2:
                    $arr['reply_state'] = [$arr['reply_state'],'查无商品'];
                    break;
                case 3:
                    $arr['reply_state'] = [$arr['reply_state'],'后台删除'];
                    break;
                case 4:
                    $arr['reply_state'] = [$arr['reply_state'],'客户删除'];
                    break;
            }
        }
        return $arr;
    }
    /**
     * 生成订单号
     * @brief alisaxu 2015-11-24
    */
    public static function createOrderNum()
    {
        return date('YmdHis').rand(100000,999999);
    }
    /**
     * @brief 是否允许退款申请
     * @param array $orderRow 订单表的数据结构
     * @return boolean true or false
     */
    public static function isRefundmentApply($orderRow)
    {
        //已经付款
        if($orderRow['pay_status'] == 1 && $orderRow['status'] != 6)
        {
            return true;
        }
        return false;
    }
    /**
     * @alisaxu 产生退款id
     * @return string 退款单id
     */
    public static function createRefundNum(){
        return 'RD'.date('YmdHis').rand(100000,999999);
    }
    /**
     * 支付成功后修改订单扩展状态
     * @param $orderNo  string 订单编号
     * @param $admin_id int    管理员ID
     * @param $note     string 收款的备注
     * @param $trade_no 支付宝交易流水号
     * @return false or int order_id
     */
    public static function updateOrderStatusExtend($orderNo,$admin_id = '',$note = '',$trade_no='')
    {
        //获取订单信息
        $orderRow  = Order_extend::findOne(['order_no' =>$orderNo]);

        if(empty($orderRow))
        {
            return false;
        }
        // 获取收货人信息
        $id = $orderRow['order_id'];
        self::updateStore($id,'reduce');
        $accept = Order::findOne(["id" => $id]);
        if($orderRow['pay_status'] == 1)
        {
            return $orderRow['order_id'];
        }
        else if($orderRow['pay_status'] == 0)
        {
            $dataArray = array(
                'pay_time'   => Date("Y-m-d H:i:s"),
                'pay_status' => 1,
            );
            $where = 'order_no = '.$orderNo;
            $is_success = Order_extend::updateData($dataArray,$where);
            if($is_success == '')
            {
                return false;
            }

            // 改变订单支付状态
            self::updateOrderPayStatus($orderRow['order_id'], $accept['accept_name'], $orderNo);



            return $orderRow['order_id'];
        }
        else
        {
            return false;
        }
    }

    /**
     * 改变订单支付状态
     */
    public static function updateOrderPayStatus($order_id='', $user, $orderNo)
    {
        if(intval($order_id) <= 0) return false;
        // 更新订单支付状态
        $orderListStatus 	= array();
        $isFlag				= false;		// 是否为订金支付
        $orderListStatusTemp = Order_extend::findAll(['order_id' =>$order_id]);
        if(!empty($orderListStatusTemp)){
            foreach($orderListStatusTemp as $ok=>$ov){
                // 计算还有几单未支付
                if($ov['pay_status'] == 0) $orderListStatus[$ov['flag']] = isset($orderListStatus[$ov['flag']]) ? intval($orderListStatus[$ov['flag']])+1 : 1;

                // 是否存在订金支付
                if($ov['flag'] == 1) $isFlag = true;
            }
        }
        // 有订金
        if(true == $isFlag){
            // 订金和尾款都支付完成
            if(!isset($orderListStatus[1]) && !isset($orderListStatus[0])){
                $orderData = array(
                    'pay_status'	=> 1,
                    'pay_time'    => Date("Y-m-d H:i:s"),
                    'status'		=> 2
                );
                $where = 'id ='.$order_id;
                Order::updateData($orderData,$where);
                // 发送邮件
                // 获取邮件
                $goods = Order_goods::findOne(["order_id" => $order_id]);
                if (isset($goods['goods_id'])) {
                    $goods_id = $goods['goods_id'];
                    //获取发件者以及收件者信息
                    $sellerInfo = self::getsendmail($goods_id);

//                    $email = "alisax@polylink.net";
                    //收件人
                    $mailAddress = yii::$app->params['noticeMail']['on-off']?Util::getNoticeMallConfig('ucenter_email'):$sellerInfo['email'];
                    $seller_name = $sellerInfo['seller_name'];
                    $title = "订单支付成功【尾款 - {$orderNo}】";
                    // 获取当前用户名
                    $message = "订单支付尾款成功";
                    //发送邮件
                    self::sendmail($mailAddress,$title,$message);
                }
            }

            // 订金支付完成
            elseif(!isset($orderListStatus[1])){
                $orderData = array(
                    'pay_status' => 2
                );
                $where = 'id ='.$order_id;
                Order::updateData($orderData,$where);
                // 发送邮件
                // 获取邮件
                $goods = Order_goods::findOne(["order_id" => $order_id]);
                if (isset($goods['goods_id'])) {
                    $goods_id = $goods['goods_id'];
                    //获取发件者以及收件者信息
                    $sellerInfo = self::getsendmail($goods_id);

                    //收件人
                    $mailAddress = yii::$app->params['noticeMail']['on-off']?Util::getNoticeMallConfig('ucenter_email'):$sellerInfo['email'];
//                    $email = "alisax@polylink.net";
                    $seller_name = $sellerInfo['seller_name'];
                    $title = "订单支付成功【定金 - {$orderNo}】";
                    // 获取当前发送的信息
                    $message = "订单支付定金成功";
                    //发送邮件
                    self::sendmail($mailAddress,$title,$message);
                }
            }
        }

        // 无定金
        else{
            if(!isset($orderListStatus[0])){
                $orderData = array(
                    'pay_status'	=> 1,
                    'pay_time'    => Date("Y-m-d H:i:s"),
                    'status'		=> 2
                );
                $where = 'id ='.$order_id;
                Order::updateData($orderData,$where);

                // 发送邮件
                // 获取邮件
                $goods = Order_goods::findOne(["order_id" => $order_id]);
                if (isset($goods['goods_id'])) {
                    $goods_id = $goods['goods_id'];
                    //获取发件者以及收件者信息
                    $sellerInfo = self::getsendmail($goods_id);

                    //收件人
                    $mailAddress = yii::$app->params['noticeMail']['on-off']?Util::getNoticeMallConfig('ucenter_email'):$sellerInfo['email'];
//                    $email = "alisax@polylink.net";
                    $seller_name = $sellerInfo['seller_name'];
                    $title = "订单支付成功【全额 - {$orderNo}】";
                    // 获取当前发送的信息
                    $message = "订单支付成功";
                    //发送邮件
                    self::sendmail($mailAddress,$title,$message);
                }
            }
        }
    }
    //获取发送邮件的相关信息
    public static function getsendmail($goods_id){
        $GoodsTB = goods::tableName();
        $SellerTB = seller::tableName();
        $query = new Query;
        $query->select(['*'])
            ->from($SellerTB . 'AS sel')
            ->leftJoin($GoodsTB . 'AS go', 'go.seller_id = sel.id')
            ->where('go.id = ' . $goods_id);
        $sellerInfo = $query->one();
        return $sellerInfo;
    }
    //发送邮件
    public static function sendmail($email,$title,$message){
        $sender = yii::$app->params['email']['address'];
        $res = Yii::$app->mailer->compose()
            ->setFrom($sender)
            ->setTo($email)
            ->setSubject($title)
            ->setTextBody($message)
            ->send();
        return $res;
    }
    /**
     * 订单商品数量更新操作[公共]
     * @param $order_id 订单ID
     * @param $type 增加或者减少 add 或者 reduce
     */
    public static function updateStore($order_id,$type = 'add')
    {
        $newStoreNums  = 0;
        $updateGoodsId = array();
        $goodsList     = Order_goods::findAll(['order_id' => $order_id]);

        foreach($goodsList as $key => $val)
        {
            //货品库存更新
            if($val['product_id'] != 0)
            {
                $productsRow = Products::findOne(['id' =>$val['product_id']]);
                $localStoreNums = $productsRow['store_nums'];

                //同步更新所属商品的库存量
                if(in_array($val['goods_id'],$updateGoodsId) == false)
                {
                    $updateGoodsId[] = $val['goods_id'];
                }

                $newStoreNums = ($type == 'add') ? $localStoreNums + $val['goods_nums'] : $localStoreNums - $val['goods_nums'];
                $newStoreNums = $newStoreNums > 0 ? $newStoreNums : 0;

                $productsRow->store_nums = $newStoreNums;
                $productsRow->update();
            }
            //商品库存更新
            else
            {
                $goodsRow = Goods::findOne(['id' => $val['goods_id']]);
                $localStoreNums = $goodsRow['store_nums'];

                $newStoreNums = ($type == 'add') ? $localStoreNums + $val['goods_nums'] : $localStoreNums - $val['goods_nums'];
                $newStoreNums = $newStoreNums > 0 ? $newStoreNums : 0;

                $goodsRow->store_nums = $newStoreNums;
                $goodsRow->update();
            }

            //更新销售量sale字段，库存减少销售量增加，两者成反比
            $saleData = ($type == 'add') ? -$val['goods_nums'] : $val['goods_nums'];
            $goodsRow = Goods::findOne(['id' => $val['goods_id']]);
            $goodsRow ->sale = $goodsRow['sale'] + $saleData;
            $goodsRow->update();
        }
        //更新统计goods的库存
        if($updateGoodsId)
        {
            foreach($updateGoodsId as $val)
            {
                $store_nums = 0;
                $productsInfo = Products::findAll(['goods_id' =>$val]);
                foreach($productsInfo as $k=>$v){
                    $store_nums += $v['store_nums'];
                }
                $data = ['store_nums' => $store_nums];
                Goods::updateData($data,'id = '.$val);
            }
        }
    }
}