<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2015/3/31
 * Time: 16:39
 */

$config = [];
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=139.196.16.146;dbname=jz-life-test4',
            'username' => 'mallyy',
            'password' => 'Onramp9460',
            'charset' => 'utf8',
        ],
        'user' => [
            'identityClass' => 'api\modules\v1\models\User',
            'enableAutoLogin' => false,
            'enableSession' => false,
            'loginUrl' => null
        ],
        'request' => [
            'class' => '\yii\web\Request',
            'enableCookieValidation' => false,
            'parsers' => [
                'application/json' => 'yii\web\JsonParser',
            ],
        ],
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'enableStrictParsing' => false,
            'rules' => [
                [
                    'class' => 'yii\rest\UrlRule',
                    'controller' => 'v0/user',
                ],
                [
                    'class' => 'yii\rest\UrlRule',
                    'controller' => ['v1/user','v1/search','v1/brand','v1/account'],
                ],
            ],
        ],
    ]
];