<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2015/3/31
 * Time: 16:39
 */
$params = array_merge(
    require(__DIR__ . '/params.php'),
    require(__DIR__ . '/params-local.php')
);

return [
    'id' => 'app-api',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'vendorPath' => dirname(dirname(__DIR__)) . '/vendor',
    'timeZone'=>'Asia/Chongqing',//设置时区
    'modules' => [
        'v0' => [
            'class' => 'api\modules\v0\Module'
        ],
        'v1' => [
            'class' => 'api\modules\v1\Module'
        ],
    ],
    'controllerMap' => [
        'queue' => 'wh\queue\console\controllers\QueueController'
    ],
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=139.196.16.146;dbname=jz-life-test',
            'username' => 'mallyy',
            'password' => 'Onramp9460',
            'charset' => 'utf8',
        ],
        'user' => [
            'identityClass' => 'api\modules\v1\models\User',
            'enableAutoLogin' => false,
            'enableSession' => false,
            'loginUrl' => null
        ],
        'request' => [
            'class' => '\yii\web\Request',
            'enableCookieValidation' => false,
            'parsers' => [
                'application/json' => 'yii\web\JsonParser',
            ],
        ],
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'enableStrictParsing' => false,
            'rules' => [
                [
                    'class' => 'yii\rest\UrlRule',
                    'controller' => 'v0/user',
                ],
                [
                    'class' => 'yii\rest\UrlRule',
                    'controller' => ['v1/user','v1/search','v1/brand','v1/account'],
                ],
            ],
        ],

        'redis' => [
            'class' => 'yii\redis\Connection',
            'hostname' => 'localhost',
            'port' => 6379,
            'database' => 0,
        ],

        'mongodb' => [
            'class' => '\yii\mongodb\Connection',
            'dsn' => 'mongodb://developer:password@localhost:27017/mydatabase',
        ],

        'search' => [
            'class' => 'EXunSearch',
            'project' => 'demo', // 搜索项目名称或对应的 ini 文件路径
            'charset' => 'utf-8', // 您当前使用的字符集（索引、搜索结果）
        ],  

        // rabbitMQ
        'amqp' => [
            'class' => 'iviu96afa\amqp\components\Amqp',
            'host' => '127.0.0.1',
            'port' => 5672,
            'user' => 'username',
            'password' => 'password',
            'vhost' => '/',
        ],

    ],
    'params' => $params,
];
