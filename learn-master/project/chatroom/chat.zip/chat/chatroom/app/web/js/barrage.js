var u = navigator.userAgent;//获取系统类型
localStorage.a = 0;
var id = localStorage.getItem('a');
var n = 0;
var first = true;
if (id == '') 
{
	localStorage.setItem('a') = 0;
}
$(function(){

        var w = document.body.clientWidth;
        if(w>768){
        	var h = screen.height;
        	$('.barrage-moveBox iframe').css({'height':h-180+'px'})
        }

		jingzhi();
	    //init_screen();
		$("#barrage_on img").click(function(){
			//判断手机系统
			if (u.indexOf('Android') > -1 || u.indexOf('Linux') > -1) {
			  $("#barrage_android.barrage-dm").toggle(500);
			} else if (u.indexOf('iPhone') > -1) {
				$("#barrage_iphone.barrage-dm").toggle(500);
			}

			$(this).eq(0).css('display','none');
			$('.barrage-off').css('display','inline-block');
		});
		$('.barrage-off').click(function(){
			$(this).css('display','none');
			$("#barrage_on").children().eq(0).css('display','inline-block');
		});
		$("#barrage_btn").click(function(){
			//判断手机系统
			if (u.indexOf('Android') > -1 || u.indexOf('Linux') > -1) {
			  $("#barrage_iphone.barrage-dm").hide();
			  $("#barrage_android.barrage-dm").show();
			} else if (u.indexOf('iPhone') > -1) {
			  $("#barrage_iphone.barrage-dm").show();
			  $("#barrage_android.barrage-dm").hide();
			}

			var nickname = $('#barrage-name').val();
			var message = $('#barrage_input').val();
			if ( $.trim(message).length>0) {
				var date = new Date();
				var month = date.getMonth() + 1;
				if (month >= 1 && month <= 9) {
					month = "0" + month;
				}
				var strDate = date.getDate();
				if (strDate >= 0 && strDate <= 9) {
					strDate = "0" + strDate;
				}

		    var time =  month + "-" + strDate + " " + date.getHours() + ":" + date.getMinutes(); 
			var FullDate = date.getFullYear() + "-" + time + ":" + date.getSeconds()
			var barrageHtml="<dd><ul><li class='t1'>" + nickname + ": </li><li class='t2'>" + message + "</li><li class='t3'>" + time + "</li></ul></dd>";
			$(barrageHtml).hide().prependTo($('#barrage-list')).slideDown(1000);

				$.ajax({
					url:'/index.php?r=site/insert',
					type:'post',
					data:{nickname:nickname,content:message,addtime:FullDate},
					success:function(data) {
						console.log(data);
					}
				});
				var div="<div style='color:#ff0000'>"+ message +"</div>";

		        $(".barrage-dm .d_show").append(div);
		        $('#barrage_input').val(' ').attr('placeholder', '说点什么...');
		        init_screen(nickname);
			}
		});
		var setting = {
			url:'/index.php?r=site/data&ran=111',
			dataType:'json',
			type:'get',
			data:{id:localStorage.a},
			success:function(data) {
				console.log(localStorage.getItem('a'));
				//$('#barrage-list').html("")
				var	barrageHtml = '';
				var nickname = $('#barrage-name').val();
				//$('#content li:first-child').remove(); // 添除上一次加载所有的 li
				var len = data.length;
				var barrageHtml;
				if (len >= 1) {
					
					for (var i = 0; i < len; i ++) {
						if (i == 0 && data[i]['id'] > localStorage.a) {
							localStorage.a = data[i]['id'];
						}
						if (data[i]['status'] == 0 && data[i]['nickname'] != nickname) {
							var div="<div>" + data[i]['content'] + "</div>";
		                    $(".barrage-dm .d_show").append(div);
		                    init_screen();
						}
						barrageHtml = "<dd><ul><li class='t1'>" + data[i]['id'] + ": </li><li class='t2'>" + data[i]['content'] + "</li><li class='t3'>" + data[i]['addtime'] + "</li></ul></dd>";
						$(barrageHtml).hide().appendTo($('#barrage-list')).slideDown(300);
					}

				}
			}
		}
		//$.ajax(setting);

		setInterval(test, 2000);
		//setInterval(function(){$.ajax(setting)}, 100);
	});
//初始化弹幕
		function test(){
			x = localStorage.a;
					var setting2 = {
			url:'/index.php?r=site/data&ran=111',
			dataType:'json',
			type:'get',
			data:{id:x},
			success:function(data) {
				//$('#barrage-list').html("")
				var	barrageHtml = '';
				var nickname = $('#barrage-name').val();
				//$('#content li:first-child').remove(); // 添除上一次加载所有的 li
				var len = data.length;
				var barrageHtml;
				if (len > 1) {					
					for (var i = 0; i < len; i ++) {
						if (i == len) {
							break;
						}
						if (i == 0 && data[i]['id'] > localStorage.a) {
							localStorage.a = data[i]['id'];
						}
						if (data[i]['status'] == 0 && data[i]['nickname'] != nickname &&!first) {
							var div="<div style='#ffff00'>" + data[i]['content'] + "</div>";
							$(".barrage-dm .d_show").append(div);
							init_screen(data[i]['nickname']);
							
						}
						barrageHtml = "<dd><ul><li class='t1'>" + data[i]['nickname'] + ": </li><li class='t2'>" + data[i]['content'] + "</li><li class='t3'>" + data[i]['addtime'] + "</li></ul></dd>";
						$(barrageHtml).hide().appendTo($('#barrage-list')).slideDown(300);
					}
					if(first){
						var firstLoad = setInterval(function(){
						if (n == len) {
							first = false;
							clearInterval(firstLoad)
							return false;
						}
						if (data[n]['status'] == 0 && data[n]['nickname'] != nickname) {
							var div="<div style='color:#ffff00;'>" + data[n]['content'] + "</div>";
							$(".barrage-dm .d_show").append(div);
							init_screen(data[n]['nickname']);
						}
						n++;
					},1000)
					}
					
				} else if (len == 1) {
					localStorage.a = data[0]['id'];
					if ($('#barrage-list ul:first li:eq(1)').text() != data[0]['content']) {
						barrageHtml = "<dd><ul><li class='t1'>" + data[0]['nickname'] + ": </li><li class='t2'>" + data[0]['content'] + "</li><li class='t3'>" + data[0]['addtime'] + "</li></ul></dd>";
					    $(barrageHtml).hide().prependTo($('#barrage-list')).slideDown(300);
					    if (data[0]['nickname'] != nickname) {
					    	var div="<div style='color:#ffff00;'>" + data[0]['content'] + "</div>";
							$(".barrage-dm .d_show").append(div);
							init_screen(data[0]['nickname']);
					    }
					}
				}
			}
		}
		$.ajax(setting2);
	}
	function init_screen(color){
		var _top=0;
		$(".d_show").find("div").show().each(function(){
			_width = $(this).width();
			$(this).css({'display':'inline-block'})
			var _left=$(window).width()-$(this).width();
			var _height=$('.barrage-moveBox').height();
			var time;

			_top=_top+28;
			if(_top>=_height*0.42){
				_top=0;
			}
			//判断手机系统
			if (u.indexOf('Android') > -1 || u.indexOf('Linux') > -1) {
				$(this).css({left:_left,top:0});
				    time=3000;
				if($(this).index()%2==0){
					time=3000;
				}
			} else if (u.indexOf('iPhone') > -1) {
				$(this).css({left:_left,top:_top});
				time=8000;
				if($(this).index()%2==0){
					time=8000;
				}
			}else{
				$(this).css({left:_left,top:'20px'});
				    time=8000;
				if($(this).index()%2==0){
					time=8000;
				}
			}
			
			
			$(this).animate({left:"-"+_width+"px"},time,function(){
				$(this).remove();
			});
		});
	}

	//随机获取颜色值
	function getReandomColor(color){
		var col = '#ffff00';
		var nickname = $('#barrage-name').val();
		if (nickname == color) {
		 	col = '#ff0000';
	    }
		return col;
		// return '#'+(function(h){
		// return new Array(7-h.length).join("0")+h
		// })((Math.random()*0x1000000<<0).toString(16))
	}
	//禁止滑动页面
	function jingzhi(){
		var jinzhi=0;
		document.addEventListener("touchmove",function(e){
		if(jinzhi==0){
		e.preventDefault();
		e.stopPropagation();
		}
		},false);
	}