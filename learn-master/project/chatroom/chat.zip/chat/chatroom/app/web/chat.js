$(function() {
	$('#sumbtn').click(function(){
		var message = $('#message').val();
		var nickname = $('#nickname').val();
		$('#content').append("<li>" + nickname + "说 : " + message + "</li>");
		$.ajax({
			url:'/index.php?r=chat/insert',
			type:'post',
			data:{nickname:nickname,content:message},
			success:function(data) {
				console.log(data);
			}
		});
	});
	var setting = {
		url:'/index.php?r=chat/index',
		dataType:'json',
		success:function(data) {
			$('#content').html("")
			//$('#content li:first-child').remove(); // 添除上一次加载所有的 li
			var len = data.length;
			if (len) {
				for (var i = 0; i < len; i ++) {
					$('#content').append("<li>" + data[i]['nickname'] + "说 : " + data[i]['content'] + "</li>");
				}
			}
			setTimeout(function(){$.ajax(setting)}, 2000);
		}
	}
	$.ajax(setting);
});