$(function() {
	$('#barrage_btn').click(function(){
		var nickname = $('#barrage-name').val();
		var message = $('#barrage_input').val();
		var date = new Date();
		date = date.getMonth() + 1 + "-" + date.getDate() + " " + date.getHours() + ":" + date.getMinutes(); 
		$('#barrage-list').append("<dd><ul><li class='t1'>" + nickname + ": </li><li class='t2'>" + message + "</li><li class='t3'>" + date + "</li></ul></dd>");
		$.ajax({
			url:'/index.php?r=chat/insert',
			type:'post',
			data:{nickname:nickname,content:message},
			success:function(data) {
				console.log(data);
			}
		});
	});
	var setting = {
		url:'/index.php?r=chat/index',
		dataType:'json',
		success:function(data) {
			$('#content').html("")
			//$('#content li:first-child').remove(); // 添除上一次加载所有的 li
			var len = data.length;
			if (len) {
				for (var i = 0; i < len; i ++) {
					$('#content').append("<li>" + data[i]['nickname'] + "说 : " + data[i]['content'] + "</li>");
				}
			}
			setTimeout(function(){$.ajax(setting)}, 2000);
		}
	}
	$.ajax(setting);
});