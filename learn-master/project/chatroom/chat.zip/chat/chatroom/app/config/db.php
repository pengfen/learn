<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=139.196.155.15;dbname=chatroom_test',
    'username' => 'chatroom',
    'password' => 'chatroom123',
    'charset' => 'utf8',
];
