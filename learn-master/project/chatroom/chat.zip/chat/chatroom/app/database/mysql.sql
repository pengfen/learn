CREATE TABLE `chatroom_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '用户昵称',
  `userIP` varchar(20) NOT NULL DEFAULT '' COMMENT '用户IP地址',
  `content` varchar(255) NOT NULL DEFAULT '' COMMENT '用户内容',
  `addtime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '添加时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户记录表';