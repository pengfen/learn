<?php
namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use app\models\Chat;

class ChatController extends Controller
{
	public $layout = false;
	public function actionIndex()
	{
		return $this->render('index');
	}

	public function actionInsert()
	{
		$request = Yii::$app->request;
		$postData = $request->post();
		$chat = new Chat();
		$chat->nickname = $postData['nickname'];
		$chat->content = $postData['content'];
		$chat->addtime = $postData['addtime'];
		//$chat->addtime = date('Y-m-d H:i:s', time());

		if ($chat->validate()) {
			$chat->save();
			echo '调用成功';
		} else {
			var_dump($chat->getErrors());
		}
	}

	public function actionData() {
		sleep(2);
		$name = Chat::find()->orderby('addtime DESC')->limit(7)->asArray()->all();
		foreach ($name as $key => $value) {
			$time[$key] = $value['addtime'];
		}
		array_multisort($time, SORT_ASC, $name); // 根据时间数组重新排序
		echo json_encode($name);
	}
}