<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\Chat;

class SiteController extends Controller
{
    public $layout = false;
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    public function actionLogin()
    {
        if (!\Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    public function actionAbout()
    {
        return $this->render('about');
    }

    public function actionChat()
    {
        return $this->render('chat');
    }

    public function actionDemo()
    {
        return $this->render('demo');
    }

    public function actionIndex()
    {
        return $this->render('index');
    }

    public function actionInsert()
    {
        $request = Yii::$app->request;
        $postData = $request->post();
        $chat = new Chat();
        $chat->nickname = $postData['nickname'];
        $chat->content = $postData['content'];
        $chat->addtime = $postData['addtime'];
        //$chat->addtime = date('Y-m-d H:i:s', time());

        if ($chat->validate()) {
            $chat->save();
        } else {
            var_dump($chat->getErrors());
        }
    }

    public function actionData() {
        $request = Yii::$app->request;
        $id = $request->get('id',0);
        $id = $_GET['id'];
        //print_r($_GET);
        //$id = $postData['id'];
        if ($id) {
            $name = Chat::find()->orderby('id DESC')->where(['>', "id", $id])->asArray()->all();
        } else {
            $name = Chat::find()->orderby('id DESC')->limit(7)->asArray()->all();
        }
        foreach ($name as $key => $value) {
            $time[$key] = $value['addtime'];
            $name[$key]['addtime'] = date('m-d H:i', strtotime($value['addtime']));
        }
        sleep(1);
        
        // if ($name) {
        //     $count = count($name);
        //     if ($count < 7) {
        //         $info = Chat::find()->orderby('addtime DESC')->limit((7 - $count))->asArray()->all();
        //         $name = array_merge($info, $name);
        //     }
        //     foreach ($name as $key => $value) {
        //         $time[$key] = $value['addtime'];
        //         $name[$key]['addtime'] = date('m-d H:i', strtotime($value['addtime']));
        //     }
        // } else {
        //     sleep(2);
        //     $name = Chat::find()->orderby('addtime DESC')->limit(7)->asArray()->all();
        //     $sql = "update chatroom_user set status=1 where id in (";
        //     foreach ($name as $key => $value) {
        //         $sql .= $value['id'].',';
        //         $time[$key] = $value['addtime'];
        //         $name[$key]['addtime'] = date('m-d H:i', strtotime($value['addtime']));
        //     }
        //     $sql = rtrim($sql, ',');
        //     $sql .= ')';
        //     \Yii::$app->db->createCommand($sql)->execute();
        // }
        //array_multisort($time, SORT_ASC, $name); // 根据时间数组重新排序
        //echo json_encode($name);
        if ($name) {
            echo json_encode($name);
        }
    }
}
