<?php

namespace app\models;

use yii\db\ActiveRecord;

/**
  * 用户聊天记录表
*/
class Chat extends ActiveRecord
{
	public static function tableName()
	{
		return '{{%chatroom_user}}';
	}
}