<?php

use yii\helpers\Html;
?>
<div class="">
    <?= Html::beginForm(['chat/insert'], 'post') ?>
    昵称 <?= Html::input('text', 'nickname') ?> <br />
    内容 <?= Html::input('text', 'content') ?> <br />
    <?= Html::submitButton('确认提交', ['class' => 'submit']) ?>
    <?= Html::endForm() ?>
</div>