<div class=''>
<form action="" method="post">
    昵称 <input type="text" id='nickname' name='nickname' value="">
    <ul id="content">
        
    </ul>
    内容 <input type="text" id='message' name="content" value="">
	<input type="button" id='sumbtn' value="提交">
</form>
</div>