<?php
use yii\helpers\Html;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>美宝莲</title>
    <meta name="viewport" content="initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <!-- <link href="@web/css/site.css" rel="stylesheet" type="text/css"> -->
    <?=Html::cssFile('@web/css/site.css')?>
</head>
<body>
    <div class="container-full">
        <p><img src="../img/mbl_01.jpg" alt=""></p> 
        <div class="barrage-top">
        <div class="clearfix">
        <ul>
            <li class="t1"><img src="../img/mbl_04.png" alt="美宝莲"></li>
            <li class="t2"><input type="text" class="barrage-name" id="barrage-name" value="XiXi"></li>
            <li class="t3"><a href="#" id="barrage_on"><img src="../img/mbl_09.png"><img class="d-n barrage-off" src="../img/mbl_07.png"></a></li>
        </ul>  
        </div>
        </div>
        <div class="barrage-moveBox">
          <!-- <iframe frameborder="0" width="100%"  src="http://v.qq.com/iframe/player.html?vid=g00204hssh0&tiny=1&auto=1&isShowRelatedVideo=true" allowtransparency="true" allowfullscreen></iframe> -->
          <iframe frameborder="0" width="100%"  src="http://player.youku.com/embed/XMTU0MDQ1NTMwMA==" allowtransparency="true" allowfullscreen></iframe>
        <!--dm start-->
        <div class="barrage-dm" id="barrage_iphone">
            <div class="d_screen">
                <div class="d_show">
                    
                </div>
            </div>
        </div>
        <!--end dm-->
    </div>
    <div class="barrage-list">

        <div class="barrage-dm" id="barrage_android">
            <div class="d_screen">
                <div class="d_show"> 
                </div>
            </div>
        </div>

         <dl id="barrage-list">
         </dl>
     </div>
    <div class="barrage-footer">
        <div class="box">
        <input type="text" class="barrage-input" id="barrage_input" placeholder="说点什么..." value="">
        <a href="javascript:;" class="btn" id="barrage_btn"><img src="../img/mbl_17.png"></a>
        </div>
    </div>

    </div>

  
<!-- 
    // <script src="../js/jquery-1.10.1.min.js"></script>
    // <script src="../js/barrage.js"></script> -->
    <?=Html::jsFile('@web/js/jquery-1.10.1.min.js')?>
    <?=Html::jsFile('@web/js/barrage.js')?>
</body>
</html>