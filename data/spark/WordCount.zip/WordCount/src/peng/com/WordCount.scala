package peng.com

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object WordCount {
  def main(args : Array[String]) {
    /**
     * 第一步 创建 spark 的配置对象 sparkConf 
	    设置 spark 程序的运行时的配置信息 
	    例如说通过 setMaster 来设置程序要链接的 spark 集群的 master 的 URL 
	    如果设置为 local 则代表 spark 程序在本地运行 特别适合于机器配置条件非常差 (例如 只有 1G 的内存) 的初学者
     */

	    val conf = new SparkConf() //ctrl + shift + o 补全 创建sparkConf 对象
	    conf.setAppName("My First Spark App")// 设置应用程序的名称 在程序运行的监控界面可以看到名称
	    conf.setMaster("local") // 此时 程序在本地运行 不需要安装 spark 集群

	    /**
	     * 第二步 创建 SparkContext 对象
	    SparkContext 是 Spark 程序所有功能的唯一入口 无论是采用 Scala Java Python R 等都必须有一个 SparkContext
	    SparkContext 核心作用 初始化 Spark 应用程序运行所需要的核心组件 包括 DAGScheduler TaskScheduler SchedulerBackend
	    同时还会负责 Spark 程序往 master 注册程序等
	    SparkContext 是整个 Spark 应用程序中最为至关重要的一个对象
	     */
	    

	    val sc = new SparkContext(conf) // 创建 SparkContext对象 通过传入 SparkConf 实例来定制 Spark 运行的具体参数和配置信息

	    //第三步 根据具体的数据来源 (HDFS HBase Local FS DB) 通过 SparkContext 来创建 RDD 
	    //RDD 的创建基本有三种方式 根据外部的数据来源 (例如 HDFS) 根据 scala 集合 由其它的 RDD 操作数据会被 RDD 划分成为一系列的 Partitions 分配到每个 Partition 的数据属于一个 Task 的处理范畴

	    // val lines : RDD[String] = sc.textFile("D://...//README.md", 1) // 读取本地文件并设置为一个 Partitions
	    val lines = sc.textFile("F://test.txt", 1) // 读取本地文件并设置为一个 Partitions

	    /**
	     * 第四步 对初始的 RDD 进行 TransFormation 级别的处理 例如 map filter 等高阶函数等的编程 来进行具体的数据计算
	    每一行的字符串拆分成单个的单词
	     */
	    

	    // val words = lines.flatMap { line => line.split(" ")} // 对每一行的字符串进行单词拆分并把所有行的拆分结果通过 flat 合并成为一个大的单词集合
	    val words = lines.flatMap { _.split(" ") }

	    //在单词拆分的基础上对每个单词实例计数为 1 也就是 word => (word, 1)
	    //val pairs = words.map { word => (word, 1)}
	    val pairs = words.map { (_,1)}

	    //在每个单词实例计数为 1 基础之上统计每个单词在文件中出现的总次数
	    val wordCounts = pairs.reduceByKey(_+_) // 对相同的 key 进行 value 的累计 (包括 Local 和 Reducer 级别同时 Reduce)

	    wordCounts.foreach(wordNumberPair => println(wordNumberPair._1 + " : " + wordNumberPair._2))

	    sc.stop()
  }
}