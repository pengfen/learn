package peng.com

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

/**
 * 使用 scala 开发集群开发测试的 spark WordCount 程序
 */
object WC {
  def main(args : Array[String]) {
    val conf = new SparkConf()
    conf.setAppName("welcome to scala world")
    // conf.setMaster("spark://peng1:7077")
    
    val sc = new SparkContext(conf)
    
    val lines = sc.textFile("/usr/input/wc/wc")
    
    val words = lines.flatMap {_.split(" ")}
    
    val pairs = words.map {(_,1)}
    
    val wordCounts = pairs.reduceByKey(_+_)
    
    wordCounts.collect.foreach(wordNumberPair => println(wordNumberPair._1 + " : " + wordNumberPair._2))
    
    sc.stop()
  }
}