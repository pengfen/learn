package com.spark.study

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object WordCount {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf().setAppName("wordcount").setMaster("local")
    val sc = new SparkContext(conf)
    //    val lines = sc.textFile("hdfs://spark001:9000/spark.txt", 1)
    val lines = sc.textFile("spark.txt", 1)
    val words = lines.flatMap { line => line.split(" ") }
    val pairs = words.map { word => (word, 1) }
    val wordcounts = pairs.reduceByKey { _ + _ }
    wordcounts.foreach { wc => println(wc._1 + " appears " + wc._2 + " times.") }
  }
}