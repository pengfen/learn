package org.seckill.exception;

/**
 * �ظ���ɱ�쳣(����ʱ�쳣)
 * @author Administrator
 *
 */
public class RepeatKillException extends SeckillException {
	public RepeatKillException(String message) {
		super(message);
	}
	
	public RepeatKillException(String message, Throwable cause) {
		super(message, cause);
	}
}
