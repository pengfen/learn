package com.peng.mybatis.entity;

public class Orderdetail {
	private Integer id;
	private Integer itemId;
	private Integer itemNum;
	private Integer orderId;
	// ��ϸ��Ӧ����Ʒ��Ϣ
	private Items items;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getItemId() {
		return itemId;
	}
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	public Integer getItemNum() {
		return itemNum;
	}
	public void setItemNum(Integer itemNum) {
		this.itemNum = itemNum;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	@Override
	public String toString() {
		return "Orderdetail [id=" + id + ", itemId=" + itemId + ", itemNum="
				+ itemNum + ", orderId=" + orderId + "]";
	}
	public Items getItems() {
		return items;
	}
	public void setItems(Items items) {
		this.items = items;
	}
	
}
