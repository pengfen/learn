package com.peng.mybatis.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.peng.mybatis.entity.User;

public class UserDaoImpl implements UserDao{
	
	// ��Ҫ��daoʵ������ע��SqlSessionFactory
	// ����ͨ�����췽��ע��
	private SqlSessionFactory sqlSessionFactory;
	public UserDaoImpl(SqlSessionFactory sqlSessionFactory) {
		this.sqlSessionFactory = sqlSessionFactory;
	}

	public User findUserById(int id) throws Exception {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		// �ͷ���Դ
		sqlSession.close();
		return sqlSession.selectOne("test.findUserById", id);
	}

	public void insertUser(User user) throws Exception {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		// �����û�����
		User user1 = new User();
		user1.setUsername("����");
		user1.setBirthday(new Date());
		user1.setSex("Ů");
		user1.setAddress("����");
		
		sqlSession.insert("test.insertUser", user);
		
		// �ύ����
		sqlSession.commit();
		
		// �ͷ���Դ
		sqlSession.close();
	}

	public void deleteUser(int id) throws Exception {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		// ִ�в������
		sqlSession.delete("test.deleteUser", id);
		
		// �ύ����
		sqlSession.commit();
		
		// �ͷ���Դ
		sqlSession.close();
	}

	public List<User> findUserByName(String name) throws Exception {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		List<User> list = sqlSession.selectList("test.findUserByName", name);
		
		// �ͷ���Դ
		sqlSession.close();
		
		return list;
	}

}
