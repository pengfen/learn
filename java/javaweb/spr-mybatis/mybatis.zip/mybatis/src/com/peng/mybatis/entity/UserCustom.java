package com.peng.mybatis.entity;

/**
 * �û���չ��
 * @author caopeng
 *
 */
public class UserCustom extends User{

}
