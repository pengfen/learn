package cn.itcast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class ReadLog {
	public static void main(String[] args) {
		File file = new File("F:\\03-01.log");
		BufferedReader reader = null;  
        try {
            InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "UTF-8");  
            reader = new BufferedReader(isr); 
            String str = null;
            String[] temp = null;
            Map<String, Object> map = new HashMap<String, Object>();  
            while ((str = reader.readLine()) != null) {  // һ��һ�ж�ȡ����
            	temp = str.split(" - - ");
            	map.put(temp[0],temp[1]); // �� ip �� ʱ��Ž� map ��
            }
            // ����ʱ��
            for(Object obj : map.keySet()){
                Object value = map.get(obj);
                // �жϵ�ǰ ip ����һ�� ip �Ƿ���ͬ �ж� ��ǰʱ������һ��ʱ���Ƿ���� 30����
            }
        } catch (IOException e) {  
            e.printStackTrace();  
        } finally {  
            if (reader != null) {  
                try {  
                    reader.close();  
                } catch (IOException e1) {  
                }  
            }  
        } 
	}
}
